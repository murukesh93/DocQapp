var objconfig = require('../config/appconfig');
var  sql = require('mssql');
const test={};

test.getDate = async function (req,res,next) {
    try {

        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);

      await  dbConn 
          .connect()
         
            var request = await new sql.Request(dbConn);
          var recordSet= await  request 
              .query('select getdate() currentDateTime;')
           
                dbConn.close();

                  var result = {
                    status: 'Success',
                   data: recordSet.recordset[0]
                  };
                  return result; 

    }
    catch (ex) {

    throw ex;
    }
  }

  module.exports=test;