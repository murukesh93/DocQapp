const jwt = require('jsonwebtoken');
const objCommon=require('./common');
const config = require('../config/appconfig');
 
exports.VerifyToken = function(req, res, next) {
  try {
    const userAccessToken = req.headers.authorization;
    if (!!!userAccessToken) {
      var result = { status: 'Error', message: 'Invalid request' };
      return res.status(401).json(result);
    }
    var decoded = jwt.verify(
      objCommon.decryptString(userAccessToken),
      config.JWTSecretKey
    ); 
    next();   
   
  } catch (ex) {
    result = { status: 'Error', message: ex.message };
    return res.status(401).json(result);
  }
};
