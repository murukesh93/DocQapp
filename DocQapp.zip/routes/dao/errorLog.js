var objconfig=require('../config/appconfig')
var sql = require('mssql');
var errorLog={
// create error log

    saveLog: function(functionName,errorMessage){ 
        try{ 
            var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
            dbConn
              .connect()
              .then(function() {
                var request = new sql.Request(dbConn);
                request 
                  .input('functionName', sql.VarChar, functionName)
                  .input('errorMessage',sql.VarChar,  JSON.stringify(errorMessage) ) 
                  .execute('spSaveErrorLog')
                  .then(function(recordSet) {
                    dbConn.close();  
                    return {status: 'Success'};
                  })
                  .catch(function(err) {  
                    dbConn.close(); 
                    return {status: 'Error',message:err.message};
                  });
              })
              .catch(function(err) { 
                return {status: 'Error',message:err.message};
              });

    }
        catch(ex){ 
            return {status:'Error',message:ex.message};
        }
    }
 
} 

module.exports=errorLog;
 
