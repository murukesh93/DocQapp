var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');
var objCommon = require('./common');
var axios = require('axios');

var authorization = {

    getToken: async function () {
        try {
            var token;
            const config = {
                method: 'POST',
                url: "https://testing.notarycam.com/api/v4/authorize",

                data: {
                    partnerId: objconfig.partnerId,
                    apiKey: objconfig.apiKey,
                    apiSecret: objconfig.apiSecret
                }
            }

            await axios(config)
                .then(async function (response) {
                    token=response.data.token          
                });

                var result = {
                    token: token
                }
                return result;  

        }
        catch (ex) {

            return ex.message;
        }

    }

}
module.exports = authorization;