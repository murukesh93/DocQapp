var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');
var objCommon = require('./common');

var tagDAO = {

saveTag: async function (req, res, next) {

    try {

        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await  dbConn.connect()
      
            var request = await new sql.Request(dbConn); 
           var recordSet= await  request
              .input('tagId', sql.Int, req.body.tagId)
              .input('tagName', sql.VarChar, req.body.tagName)
              .input('color', sql.VarChar, req.body.color)
              .input('userId', sql.Int, req.body.userId)
              .input('action', sql.VarChar, req.body.action) 
              .execute('spSaveTag')
            
                    await dbConn.close();

                if (recordSet.recordset[0].errorMessage == 'Success') { 
            
                  var result = {

                    status: 'Success',
                    message: req.body.tagId == 0 ? 'Record Saved Successfully!' : 'Record Updated Successfully!',
                    tagId: recordSet.recordset[0].tagId,

                  }; 
                  return result;
                } else {
                  var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage,
                  };
                  return result;
                }
           
   

    }  catch(ex){ 
      
      throw ex;
    }
  },

listTag: async function (req, res, next) {
    try {

        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await  dbConn
          .connect()
         
            var request = await new sql.Request(dbConn);
            var recordSet= await request
            .input('count', sql.Int, req.query.count)
            .input('Offset', sql.Int, req.query.offset)
            .input('tagName', sql.VarChar, req.query.tagName)
            .input('tagId', sql.VarChar, req.query.tagId)
            .input('userId', sql.VarChar, req.query.userId)
              .execute('spGetTag')
          
                await dbConn.close();
                if (recordSet.recordset.length > 0) {
                  
                  var result = {
                    status: 'Success', 
                    count: recordSet.recordsets[0][0].totalCount,
                   data: recordSet.recordsets[1],
                  }
                  return result;

                }
                else {
                  var result = {
                    status: 'Success',
                    message: 'No record found',
                  };
                  return result;
                }
    }
    catch (ex) {
   
    throw ex;
    }

  },

  
}

module.exports = tagDAO;
