var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');
var objCommon = require('./common');
var objAuth = require('./authorizationTry')
var axios = require('axios');
const { add } = require('lodash');
var fs = require('fs');
var FormData = require('form-data');
var user = {

  saveUser: async function (req, res, next) {
    try {
      const address = {};
      address.country = req.body.country;
      address.street = req.body.street;
      address.city = req.body.city;
      address.state = req.body.state;
      address.postalCode = req.body.postalCode;

      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/users",
        headers: {
          Authorization: authorization,
        },
        data: {
          departments: req.body.departments,
          email: req.body.email,
          namePrefix: req.body.namePrefix,
          firstName: req.body.firstName,
          middleName: req.body.middleName,
          lastName: req.body.lastName,
          nameSuffix: req.body.nameSuffix,
          phone: req.body.phone,
          dateOfBirth: req.body.dateOfBirth,
          address: address
        }
      }

      var result;

      await axios(config)
        .then(async function (response) {

          result = {
            status: 'Success',
            data: response.data.user

          }


        }).catch(function (err) {
          result = {
            status: 'Error',
            message: err.response.data.error.message
          }

        });
      return result;
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  getUser: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/users/search",

        headers: {
          Authorization: authorization,
        },
        data: {
          userIds: req.body.userIds,
          emails: req.body.emails,
        }
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              result = {
                status: 'Success',
                data: response.data.users
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  getUserDetails: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'GET',
        url: "https://testing.notarycam.com/api/v4/users/" + req.query.userId,

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              console.log(response);
              result = {
                status: 'Success',
                data: response.data.user
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  transactions: async function (req, res, next) {
    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/transactions",
        headers: {
          Authorization: authorization,
        },
        data: {
          department: req.body.department,
          participants: req.body.participants,
        }
      }
      var result;
      try {
        await axios(config)
          .then(async function (response) {

            if (response.data.success == true) {
              result = {
                status: 'Success',
                data: response.data.transaction

              }
            }
            else {
              result = {
                status: 'Error',
                message: response.data.success

              }
            }


          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  getTransactions: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/transactions/search",

        headers: {
          Authorization: authorization,
        },
        body: {
          userIds: req.body.userIds,
          emails: req.body.emails,
          departmentIds: req.body.departmentIds
        }
      }

      var result;
      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              result = {
                status: 'Success',
                data: response.data.transactions
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  getTransactionDetails: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'GET',
        url: "https://testing.notarycam.com/api/v4/transactions/" + req.query.transactionId,

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              console.log('hiii');
              result = {
                status: 'Success',
                data: response.data.transaction
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  activateTransactionDetails: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'PUT',
        url: "https://testing.notarycam.com/api/v4/transactions/" + req.body.transactionId + "/activate",

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {

            if (response.data.success == true) {
              result = {
                status: 'Success',
                meessage: 'Transaction Activated'
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'Transaction not Activated'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  archiveTransactionDetails: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'PUT',
        url: "https://testing.notarycam.com/api/v4/transactions/" + req.body.transactionId + "/archive",

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {

            if (response.data.success == true) {
              result = {
                status: 'Success',
                meessage: 'Transaction Archived'
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'Transaction not Archived'
              }
            }

          }).catch(function (err) {
            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (ex) {
        result = {
          status: 'Error',
          message: err.response.data.error
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  addParticipantsToTransaction: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/transactions/" + req.body.transactionId + "/participants",

        headers: {
          Authorization: authorization,
        },
        data: {
          participants: req.body.participants
        }
      }

      var result;

      await axios(config)
        .then(async function (response) {
          result = {
            status: 'Success',
            data: response.data.participants
          }

        })
        .catch(function (err) {
          result = {
            status: 'Error',
            message: err.response.data.error.message
          }

        });
      return result;


    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  removeParticipantsFromTransactions: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'PUT',
        url: "https://testing.notarycam.com/api/v4/transactions/" + req.body.transactionId + "/participants/" + req.body.userId + "/archive",

        headers: {
          Authorization: authorization,
        },

      }

      var result;

      await axios(config)
        .then(async function (response) {

          console.log(response);

          result = {
            status: 'Success',
            meessage: 'Participants Removed'
          }


        }).catch(function (err) {
          result = {
            status: 'Error',
            message: err.response.data.error.message
          }

        });

      return result;

    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },

  getDocumentDetails: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'GET',
        url: "https://testing.notarycam.com/api/v4/transactions/" +
          req.query.transactionId + "/documents/" + req.query.documentId,

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              result = {
                status: 'Success',
                data: response.data.document
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
            }

          }).catch(function (err) {

            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (err) {
        result = {
          status: 'Error',
          message: err.meessage
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: err.response.data.error
      }
      return result;
    }
  },


  downloadDocuments: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'GET',
        url: "https://testing.notarycam.com/api/v4/documents/" +
          req.query.transactionId + "/" + req.query.documentId,

        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)
          .then(async function (response) {
            if (response.data.success == true) {
              result = {
                status: 'Success',
                data: response.data.document
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
              return result;
            }

          }).catch(function (err) {

            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (err) {

        result = {
          status: 'Error',
          message: err.meessage
        }
        return result;
      }
    } catch (ex) {

      result = {
        status: 'Error',
        message: ex.meessage
      }
      return result;
    }
  },

  removeDocuments: async function (req, res, next) {

    try {
      var token = await objAuth.getToken();

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'PUT',
        url: "https://testing.notarycam.com/api/v4/transactions/" +
          req.body.transactionId + "/documents/" + req.body.documentId + "/archive",


        headers: {
          Authorization: authorization,
        },
      }

      var result;

      try {
        await axios(config)

          .then(async function (response) {

            console.log(response);
            if (response.data.success == true) {
              result = {
                status: 'Success',
                message: 'Document Removed',
                documentId: response.data.documentId
              }
            }
            else {
              result = {
                status: 'Error',
                message: 'No record found'
              }
              return result;
            }

          }).catch(function (err) {

            result = {
              status: 'Error',
              message: err.response.data.error
            }

          });
        return result;

      }
      catch (err) {
        result = {
          status: 'Error',
          message: err.meessage
        }
        return result;
      }
    } catch (ex) {
      result = {
        status: 'Error',
        message: ex.meessage
      }
      return result;
    }
  },

  saveDocuments: async function (req, res, next) {
    try {

      var token = await objAuth.getToken();
      var FileName = (req.files.documents.path).split("\\").slice(-1);
      req.body.documentData = [{ "type": req.body.type, "fileName": FileName[0] }];

      var data = new FormData();
      data.append('documents', fs.createReadStream(req.files.documents.path));
      data.append('documentData', JSON.stringify(req.body.documentData));
      
      console.log(req.files.documents);

      var authorization = 'Bearer' + ' ' + token.token;
      const config = {
        method: 'POST',
        url: "https://testing.notarycam.com/api/v4/transactions/" +
          req.body.transactionId + "/documents/",
        headers: {
          Authorization: authorization,
          ...data.getHeaders(),
        },
        data: data,
      }
      var result;


      await axios(config)
        .then(async function (response) {

          if (response.data.success == true) {
            result = {
              status: 'Success',
              message: 'Document Added SuccessFully',
              documentsReceived: response.data.documentsReceived
            }
          }
          else {
            result = {
              status: 'Error',
              message: 'No record found'
            }
            return result;
          }

        }).catch(function (err) {

          
          result = {
            status: 'Error',
            message: err.response.data.error
          }

        });
      return result;


    } catch (ex) {
      console.log(ex);
      result = {
        status: 'Error',
        message: ex.meessage
      }
      return result;
    }
  },

  getParticipantsDetails: async function (req, res, next) {
    try {

        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await  dbConn
          .connect()
         
            var request = await new sql.Request(dbConn);
            var recordSet= await request
            .input('count', sql.Int, req.query.count)
            .input('Offset', sql.Int, req.query.offset)
            .input('name', sql.VarChar, req.query.name)
            .execute('spGetParticipants')
        
                await dbConn.close();
                if (recordSet.recordset.length > 0) {
                  
                  var result = {
                    status: 'Success', 
                    count: recordSet.recordsets[0][0].totalCount,
                   data: recordSet.recordsets[1],
                  }
                  return result;

                }
                else {
                  var result = {
                    status: 'Success',
                    message: 'No record found',
                  };
                  return result;
                }
    }
    catch (ex) {
   
    throw ex;
    }

  },

}

module.exports = user;