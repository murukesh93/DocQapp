var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');

var paymentDAO = {

  getPlan: async function (req, res, next) {
    try {

     
        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
     await   dbConn
          .connect()
        
          var request =await new sql.Request(dbConn);
          var recordSet=await   request.query('select * from tblSubscriptionPlan where isDeleted=0')  
           dbConn.close();

                data = [];
                var result = {
                  status: 'Success',
                  data: recordSet.recordsets[0]
                  
                };
                return result;
             

    }
    catch (ex) {
      
      throw ex;
    }
  },

  subscribePlans: async function (req, res, next) {
    try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
    await  dbConn.connect()
    
          var request = await new sql.Request(dbConn); 
         var recordSet= await  request
            .input('userId', sql.Int, req.body.userId)
            .input('amount', sql.Int, req.body.amount)
            .input('paymentResponse', sql.VarChar, req.body.paymentResponse)
            .input('paymentPurpose', sql.VarChar, req.body.paymentPurpose) 
            .input('bankTransactionId', sql.Int, req.body.amount)
            .input('paymentStatus', sql.VarChar, req.body.paymentStatus)
            .input('customerId', sql.Int, req.body.customerId)
            .input('subscriptionPlanId', sql.Int, req.body.subscriptionPlanId)
            .input('planDuration', sql.Int, req.body.planDuration)
            .execute('spSubscribePlan')
          console.log('test');
                  await dbConn.close();

              if (recordSet.recordset[0].errorMessage == 'Success') { 
          
                var result = {

                  status: 'Success',
                  message: recordSet.recordset[0].planId != 0 ? 'Record Saved Successfully!':'',
     

                }; 
                return result;
              } else {
                var result = {
                  status: 'Error',
                  message: recordSet.recordset[0].errorMessage,
                };
                return result;
              }
         
 

  }  catch(ex){ 
    
    throw ex;
  }
  },
  getUserSubscription: async function (req, res, next) {
    try {

     
        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
     await   dbConn
          .connect()
        
          var request =await new sql.Request(dbConn);
          var recordSet=await   request
              .input('userId', sql.Int, req.query.userId)
             
              .execute('getUserSubscription')
           
                dbConn.close();

                data = [];
                var result = {
                  status: 'Success',
                  CurrentPlan: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,
                  FuturePlan: (recordSet.recordset.length > 0) ? recordSet.recordsets[1] : data
                  
                };
                return result;
             

    }
    catch (ex) {
      
      throw ex;
    }
  },

 

}




module.exports = paymentDAO;
