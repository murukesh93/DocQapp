var objconfig = require('../config/appconfig')
var objErrorLog = require('./errorLog');
const crypto = require('crypto');
const masterKey = 'DocQApp@123!';
const encryptionType = 'aes-256-cbc';
const encodingType = 'utf8';
var sql = require('mssql');

var common = {

  encryptString: function (text) {
    try {
      var cipher = crypto.createCipher(encryptionType, masterKey);
      var crypted = cipher.update(text, encodingType, 'hex');
      crypted += cipher.final('hex');
      return crypted;
    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message }; 
    }
  },

  decryptString: function (text) {
    try {
      var decipher = crypto.createDecipher(encryptionType, masterKey);
      var dec = decipher.update(text, 'hex', encodingType);
      dec += decipher.final(encodingType);
      return dec;
    } catch (ex) {
      return text;
    }

  },

generateOTP: function (req, res, next) {
    try { 

      return new Promise(function (resolve, reject) {
        var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
        dbConn
          .connect()
          .then(function () {
            var request = new sql.Request(dbConn);
            request
              .input('email', sql.VarChar, req.body.email)
              .input('otpType', sql.VarChar, req.body.otpType)
              .input('otpValue', sql.VarChar, req.body.otp) 
              .execute('spGenerateOTP')
              .then(function (recordSet) {
                dbConn.close();

                if (recordSet.recordset[0].errorMessage == 'Success') {
                  var result = {
                    status: 'Success',
                    message: 'OTP generated successfully' 
                  }; 
                  return resolve(result);
                }
                else {
                  var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage
                  };
                  return resolve(result);
                }


              })
              .catch(function (err) {

                dbConn.close();
                var result = { status: 'Error', message: err.message };
                objErrorLog.saveLog('generateOTP', result)
                return reject(result);
              });
          })
          .catch(function (err) {
            var result = { status: 'Error', message: err.message };
            objErrorLog.saveLog('generateOTP', result)
            return reject(result);
          });

      });

    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message };
      objErrorLog.saveLog('generateOTP', result)
      return reject(result);
    }
  }, 

  sendEmail: function (from, to, subject, emailContent) {
    try {
 
      
      return new Promise(function (resolve, reject) {

        var nodemailer = require('nodemailer'),
          _ = require('lodash');
        var sgTransport = require('nodemailer-sendgrid-transport');
        var options = {
          auth: {
            api_key: objconfig.sendGridKey
          }
        };
        var client = nodemailer.createTransport(sgTransport(options));
        var email = {
          from: from,
          to: to,
          subject: subject,
          html: emailContent
        };

        client.sendMail(email, function (error, info) {
          if (error) {
            console.log('Error ' + error);
            var result = { status: 'Error', message: error.message };
            objErrorLog.saveLog('sendEmail', result)
            return reject(result);
          } else {
            console.log('info ' + JSON.stringify(info));
            console.log('error ' + JSON.stringify(error));
            result = { status: 'Success', message: 'Email sent successfully' };

            return resolve(result);
          }
        });
      });


    }
    catch (ex) {
      var result = { status: 'Error', message: ex.message };
      objErrorLog.saveLog('sendEmail', result)
      return reject(result);
    }
  },

  forgetPassword:async function(req,res,next){ 
  try{ 
          var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
         await  dbConn
            .connect()
         
               var request = new sql.Request(dbConn);
            var recordSet=await  request
                .input('email', sql.VarChar, req.body.email)
                .input('password', sql.VarChar, req.body.password)
                .input('OTPValue',sql.VarChar,req.body.otpValue) 
                .execute('spForgetPassword')
     
                 await dbConn.close();
                  if (recordSet.recordset[0].errorMessage== 'Success'){ 
                      var result = {
                          status: 'Success',
                          message: 'Password updated successfully'
                         };
                        return  result;
                  }
                  else{
                      var result = {
                          status: 'Error',
                          message: recordSet.recordset[0].errorMessage
                        };
                        return result;  
                      }          
}
  catch(ex){ 

throw ex;
  }
}, 
 
changePassword:async function(req,res,next){ 
  try{ 

          var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
         await  dbConn
            .connect()
        
               var request = new sql.Request(dbConn);
            var recordSet=await  request
                .input('email', sql.VarChar, req.body.email)
                .input('oldPassword', sql.VarChar, req.body.oldPassword)
                .input('newPassword', sql.VarChar,req.body.newPassword)
                .input('agencyId',sql.Int,req.body.agencyId)

                .execute('spChangePassword')
   
                 await dbConn.close();
                  if (recordSet.recordset[0].errorMessage== 'Success'){ 
                      var result = {
                          status: 'Success',
                          message: 'Password updated successfully'
                         };
                        return  result;
                  }
                  else{
                      var result = {
                          status: 'Error',
                          message: recordSet.recordset[0].errorMessage
                        };
                        return result;  
                      }          
}
  catch(ex){ 

throw ex;
  }
}, 

getCourtDetails: async function (req, res, next) {
  try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
   await   dbConn
        .connect()
      
        var request =await new sql.Request(dbConn);
        var recordSet=await   request 
        .input('courtType', sql.VarChar, req.query.courtType)    
        .execute('spGetCourtDetails')
              dbConn.close();

              data = [];
              var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,                
              };
              return result;
           

  }
  catch (ex) {
    
    throw ex;
  }
},

getCountryDetails: async function (req, res, next) {
  try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
   await   dbConn
        .connect()
      
        var request =await new sql.Request(dbConn);
        var recordSet=await   request     
           .execute('spGetCountryDetails')
              dbConn.close();

              data = [];
              var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,                
              };
              return result;
  }
  catch (ex) {
    
    throw ex;
  }
},

getDivisionDetails: async function (req, res, next) {
  try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
   await   dbConn
        .connect()
      
        var request =await new sql.Request(dbConn);
        var recordSet=await   request     
           .execute('spGetDivisionDetails')
              dbConn.close();

              data = [];
              var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,                
              };
              return result;
  }
  catch (ex) {
    
    throw ex;
  }
},

getCaseType: async function (req, res, next) {
  try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
   await   dbConn
        .connect()
      
        var request =await new sql.Request(dbConn);
        var recordSet=await   request     
           .execute('spGetCaseType')
              dbConn.close();

              data = [];
              var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,                
              };
              return result;
  }
  catch (ex) {
    
    throw ex;
  }
},
getSubCaseType: async function (req, res, next) {
  try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
   await   dbConn
        .connect()
      
        var request =await new sql.Request(dbConn);
        var recordSet=await   request     
           .execute('spGetSubCaseType')
              dbConn.close();

              data = [];
              var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data,                
              };
              return result;
  }
  catch (ex) {
    
    throw ex;
  }
},




}
 

module.exports = common;

