var objconfig=require('../config/appconfig') 
var objErrorLog=require('./errorLog');
var datetime = require('node-datetime');
var path = require('path');
var fs = require('fs'); 
var azure = require('azure-storage');
var sql = require('mssql');

var blobsrv = azure.createBlobService(
    objconfig.accountName,
    objconfig.accountKey
)


var uploadFile={

  uploadFile: function(req,res,next){
  
    return new Promise(function(resolve, reject) {
      try {
  
    
        var accountName =objconfig.accountName; // storage account name at appSettings
        var accountKey = objconfig.accountKey; //storage account key at appSettings
        var host = accountName + '.blob.core.windows.net';
        var container = objconfig.containerName;
     
        var dt = datetime.create();
        var formatteddatetime = dt.format('Y-m-d-H-M-S');
        var fileext = [];
        fileext = req.files.file.originalFilename.split('.');
      
        var newfilename = fileext[0].replace(/[^A-Z0-9-_]/gi, '');
       
          newfilename =newfilename +  '_' + formatteddatetime +'.' +fileext[fileext.length - 1];
          if(req.query.userId >0 ){
            newfilename="user_"+req.query.userId+"/"+newfilename;
          }
     
        var blobSvc = azure.createBlobService(accountName, accountKey); 
      
        blobSvc.createContainerIfNotExists(container, {publicAccessLevel : 'blob'}, function(error, result, response){
            if(error)
            {
              var result = { status: 'Error', message: error.message }; 
              objErrorLog.saveLog('uploadFile',result)
              return  reject(result);
            }
            else{
              
               blobSvc.createBlockBlobFromLocalFile(container, newfilename, req.files.file.path, function(error, result, response){
                if(error)
                {
                  var result = { status: 'Error', message: error.message }; 
                  objErrorLog.saveLog('uploadFile',result)
                  return  reject(result);
                }    
                else{
                  var filepath='https://'+objconfig.accountName+'.blob.core.windows.net/'+objconfig.containerName+'/' +newfilename;
                  var results = { status: 'Success',filepath };  
                  return  resolve(results);
                   }
                   
               });
              
            }
         });
  
  
  
         
  
      } catch (excb1) {                        
      var result = { status: 'Error', message: excb1.message }; 
      objErrorLog.saveLog('uploadFile',result)
      return  reject(result);          
    }
  
  });
  
  
  }, 
  
  
  }



module.exports=uploadFile;