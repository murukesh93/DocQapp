var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');
var objCommon = require('./common');
var objNotary = require('./notaryCam');

var efileDAO = {

  saveFolder: async function (req, res, next) {

    try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('folderId', sql.Int, req.body.folderId)
        .input('folderName', sql.VarChar, req.body.folderName)
        .input('userId', sql.Int, req.body.userId)
        .input('parentId', sql.Int, req.body.parentId)
        .input('tagId', sql.Int, req.body.tagId)
        .input('action', sql.VarChar, req.body.action)
        .execute('spSaveFolder')

      await dbConn.close();
      if (recordSet.recordset[0].errorMessage == 'Success') {

        var result = {

          status: 'Success',
          message: req.body.folderId == 0 ? 'Record Saved Successfully!' : 'Record Updated Successfully!',
          folderId: recordSet.recordset[0].folderId,

        };
        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }



    } catch (ex) {

      throw ex;
    }
  },

  saveDocument: async function (req, res, next) {

    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('documentId', sql.Int, req.body.documentId)
        .input('tagId', sql.Int, req.body.tagId)
        .input('folderId', sql.Int, req.body.folderId)
        .input('userId', sql.Int, req.body.userId)
        .input('description', sql.VarChar, req.body.description)
        .input('fileName', sql.VarChar, req.body.fileName)
        .input('fileType', sql.VarChar, req.body.fileType)
        .input('fileSize', sql.VarChar, req.body.fileSize)
        .input('filePath', sql.VarChar, req.body.filePath)
        .input('action', sql.VarChar, req.body.action)
        .execute('spSaveDocument')

      await dbConn.close()

      if (recordSet.recordset[0].errorMessage == 'Success') {

        var result = {

          status: 'Success',
          message: req.body.documentId == 0 ? 'Record Saved Successfully!' : 'Record Updated Successfully!',
          documentId: recordSet.recordset[0].documentId,

        };
        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }



    } catch (ex) {

      throw ex;
    }
  },

  getFolderDocument: async function (req, res, next) {
    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('folderName', sql.VarChar, req.query.folderName)
        .input('folderId', sql.Int, req.query.folderId)
        .input('userId', sql.Int, req.query.userId)
        .input('folderTagId', sql.Int, req.query.folderTagId)
        .input('tagName', sql.VarChar, req.query.tagName)
        .input('folderTagName', sql.VarChar, req.query.folderTagName)
        .input('fileName', sql.VarChar, req.query.fileName)
        .input('columnName', sql.VarChar, req.query.columnName)
        .input('orderBy', sql.VarChar, req.query.orderBy)
        .execute('spGetFolderDocument')

      await dbConn.close();
      if (recordSet.recordsets[0].length > 0 || recordSet.recordsets[1].length > 0) {
        var result = {
          status: 'Success',
          files: recordSet.recordsets[0],
          folder: recordSet.recordsets[1]
        }
        return result;

      }
      else {
        var result = {
          status: 'Success',
          message: 'No record found',
        };
        return result;
      }
    }
    catch (ex) {

      throw ex;
    }

  },

  deleteFolderDocument: async function (req, res, next) {

    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('documentId', sql.VarChar, req.query.documentId)
        .input('folderId', sql.VarChar, req.query.folderId)
        .execute('spDeleteFolderDocument')
      await dbConn.close()
      if (recordSet.recordset[0].errorMessage == 'Success') {

        var result = {

          status: 'Success',
          message: 'Record deleted successfully'

        };
        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }



    } catch (ex) {

      throw ex;
    }
  },

  saveEfileUser: async function (req, res, next) {
    try {
      var notaryData = await objNotary.saveUser(req, res, next);
      if (notaryData.status == 'Success') {
        req.body.id = notaryData.data._id;
        req.body.individuationTag = notaryData.data.individuationTag;
        var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
        await dbConn.connect()
        var request = await new sql.Request(dbConn);
        var recordSet = await request
          .input('efileId', sql.Int, req.body.efileId)
          .input('userId', sql.VarChar, req.body.userId)
          .input('password', sql.VarChar, req.body.password)
          .input('namePrefix', sql.VarChar, req.body.namePrefix)
          .input('firstName', sql.VarChar, req.body.firstName)
          .input('middleName', sql.VarChar, req.body.middleName)
          .input('lastName', sql.VarChar, req.body.lastName)
          .input('nameSuffix', sql.VarChar, req.body.nameSuffix)
          .input('phone', sql.VarChar, req.body.phone)
          .input('dob', sql.VarChar, req.body.dob)
          .input('country', sql.VarChar, req.body.country)
          .input('state', sql.VarChar, req.body.state)
          .input('city', sql.VarChar, req.body.city)
          .input('street', sql.VarChar, req.body.street)
          .input('postalCode', sql.VarChar, req.body.postalCode)
          .input('id', sql.VarChar, req.body.id)
          .input('departments', sql.VarChar, req.body.departments)
          .input('individuationTag', sql.VarChar, req.body.individuationTag)
          .input('userRole', sql.VarChar, req.body.userRole)
          .input('action', sql.VarChar, req.body.action)
          .execute('spSaveEFile')

        await dbConn.close();
        req.body.password = objCommon.decryptString(req.body.password);

        if (recordSet.recordset[0].errorMessage == 'Success') {
          var result = {
            status: 'Success',
            message: req.body.efileId == 0 ? 'Record Saved Successfully.' : 'Record Updated Successfully',
            efileId: recordSet.recordset[0].efileId,

          };

          return result;
        } else {
          var result = {
            status: 'Error',
            message: recordSet.recordset[0].errorMessage,
          };
          return result;
        }

      } else {
        var result = {
          status: 'Error',
          message: notaryData.message
        }
        return result;
      }

    } catch (ex) {

      throw ex;
    }
  },

  selectEfileUser: async function (req, res, next) {
    try {


      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('efileId', sql.Int, req.query.efileId)
        .execute('spSelectEFile')

      dbConn.close();

      data = {};
      var result = {
        status: 'Success',
        data: (recordSet.recordset.length > 0) ? recordSet.recordset[0] : data
      };
      return result;


    }
    catch (ex) {

      throw ex;
    }
  },

  sigIn: async function (req, res, next) {
    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()
      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('email', sql.VarChar, req.body.email)
        .input('password', sql.VarChar, req.body.password)
        .execute('spEFileLogin')

      await dbConn.close();
      if (recordSet.recordset.length > 0) {

        var result = {
          status: 'Success',
          message: 'Login Successfull!.',
          data: recordSet.recordsets[0],
          isSignUpExist: recordSet.recordsets[1][0].isSignUpExist
        };
        return result;

      } else {
        var result = {
          status: 'Error',
          message: 'Invalid username or password',
          isSignUpExist: recordSet.recordsets[1][0].isSignUpExist
        };
        return result;
      }


    } catch (ex) {

      throw ex;
    }
  },

  selectSecurityQuestion: async function (req, res, next) {
    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request.execute('spGetSecurityQuestion')

      dbConn.close();
      var result = {
        status: 'Success',
        data: recordSet.recordset
      };
      return result;


    }
    catch (ex) {

      throw ex;
    }
  },

  saveSecurityQuestionAnswer: async function (req, res, next) {

    try {


      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()
      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('userId', sql.Int, req.body.userId)
        .input('answer', sql.VarChar, JSON.stringify(req.body.answer))
        .execute('spSaveSecurityQuestionUserAnswer')

      await dbConn.close();
      if (recordSet.recordset[0].errorMessage == 'Success') {
        var result = {
          status: 'Success',
          message: 'Record Saved Successfully.'
        };

        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }



    } catch (ex) {

      throw ex;
    }
  },

  CheckValidateSecurityQuestion: async function (req, res, next) {
    try {
      var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()

      var request = new sql.Request(dbConn);
      var recordSet = await request
        .input('userId', sql.Int, req.body.userId)
        .input('answer', sql.VarChar, JSON.stringify(req.body.answer))
        .execute('spCheckValidateSecurityQuestion')

      await dbConn.close();

      var result = {
        status: 'Success',
        message: recordSet.recordset[0].ErrorMessage
      };
      return result;

    }
    catch (ex) {

      throw ex;
    }
  },

  forgetPassword: async function (req, res, next) {
    try {
      var dbConn = new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()

      var request = new sql.Request(dbConn);
      var recordSet = await request
        .input('userId', sql.VarChar, req.body.userId)
        .input('password', sql.VarChar, req.body.password)
        .execute('spForgetPasswordForEFile')

      await dbConn.close();
      if (recordSet.recordset[0].ErrorMessage == 'Success') {
        var result = {
          status: 'Success',
          message: 'Password updated successfully'
        };
        return result;
      }
      else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].ErrorMessage
        };
        return result;
      }
    }
    catch (ex) {

      throw ex;
    }
  },

}

module.exports = efileDAO;
