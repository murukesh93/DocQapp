var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');

var caseDetails = {

    saveCaseDetails: async function (req, res, next) {

        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn.connect()
            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseId', sql.Int, req.body.caseId)
                .input('appellateCourt', sql.VarChar, req.body.appellateCourt)
                .input('judicialCourt', sql.VarChar, req.body.judicialCourt)
                .input('caseName', sql.VarChar, req.body.caseName)
                .input('caseNumberPending', sql.VarChar, req.body.caseNumberPending)
                .input('caseInitiation', sql.VarChar, req.body.caseInitiation)
                .input('pleadinginExistingCase', sql.VarChar, req.body.pleadinginExistingCase)
                .input('fileMultipleCases', sql.VarChar, req.body.fileMultipleCases)
                .input('fileSameDocument', sql.VarChar, req.body.fileSameDocument)
                .input('multipleCases', sql.VarChar, req.body.multipleCases)
                .input('proposedOrder', sql.VarChar, req.body.proposedOrder)
                .input('caseDescription', sql.VarChar, req.body.caseDescription)
                .input('caseStatus', sql.VarChar, req.body.caseStatus)
                .input('userId', sql.Int, req.body.userId)
                .input('courtId', sql.Int, req.body.courtId)
                .input('countryId', sql.Int, req.body.countryId)
                .input('divisionId', sql.Int, req.body.divisionId)
                .input('caseTypeId', sql.Int, req.body.caseTypeId)
                .input('subTypeId', sql.Int, req.body.subTypeId)
                .input('action', sql.VarChar, req.body.action)
                .execute('spSaveCaseDetails')

            await dbConn.close();


            if (recordSet.recordset[0].errorMessage == 'Success') {
                var result = {

                    status: 'Success',
                    message: req.body.caseId == 0 ? 'Record Saved Successfully' : 'Record Updated Successfully',
                    caseId: recordSet.recordset[0].caseId,

                };

                return result;
            } else {
                var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage,
                };
                return result;
            }

        } catch (ex) {
            throw ex;
        }
    },

    saveCaseAttachments: async function (req, res, next) {

        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn.connect()
            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseAttachmentsId', sql.Int, req.body.caseAttachmentsId)
                .input('filePath', sql.VarChar, req.body.filePath)
                .input('fileName', sql.VarChar, req.body.fileName)
                .input('documentId', sql.Int, req.body.documentId)
                .input('caseId', sql.Int, req.body.caseId)
                .input('fileDescription', sql.VarChar, req.body.fileDescription)
                .input('fileOrder', sql.Int, req.body.fileOrder)
                .input('action', sql.VarChar, req.body.action)
                .execute('spSaveCaseAttachments')

            await dbConn.close();


            if (recordSet.recordset[0].errorMessage == 'Success') {
                var result = {

                    status: 'Success',
                    message: req.body.caseAttachmentsId == 0 ? 'Record Saved Successfully' : 'Record Updated Successfully',
                    caseAttachmentsId: recordSet.recordset[0].caseAttachmentsId,

                };

                return result;
            } else {
                var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage,
                };
                return result;
            }

        } catch (ex) {
            throw ex;
        }
    },

    selectCaseAttachmentByCaseId: async function (req, res, next) {
        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn
                .connect()

            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseId', sql.Int, req.query.caseId)
                .input('action', sql.VarChar, req.query.action)
                .execute('spGetCaseAttachments')
            dbConn.close();

            data = [];

            var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data
            };
            return result;


        }
        catch (ex) {

            throw ex;
        }
    },

    selectPartyInformationByCaseId: async function (req, res, next) {
        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn
                .connect()

            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseId', sql.Int, req.query.caseId)
                .input('action', sql.VarChar, req.query.action)
                .execute('spGetPartyInformation')
            dbConn.close();

            data = [];

            var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data
            };
            return result;


        }
        catch (ex) {

            throw ex;
        }
    },

    savePartyInformation: async function (req, res, next) {

        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn.connect()
            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('partyInformationId', sql.Int, req.body.partyInformationId)
                .input('caseId', sql.Int, req.body.caseId)
                .input('partyName', sql.VarChar, req.body.partyName)
                .input('phoneNumber', sql.VarChar, req.body.phoneNumber)
                .input('address', sql.VarChar, req.body.address)
                .input('email', sql.VarChar, req.body.email)
                .input('type', sql.VarChar, req.body.type)
                .input('action', sql.VarChar, req.body.action)
                .execute('spSavePartyInformation')
            await dbConn.close();

            if (recordSet.recordset[0].errorMessage == 'Success') {
                var result = {

                    status: 'Success',
                    message: req.body.partyInformationId == 0 ? 'Record Saved Successfully' : 'Record Updated Successfully',
                    partyInformationId: recordSet.recordset[0].partyInformationId,

                };

                return result;
            } else {
                var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage,
                };
                return result;
            }

        } catch (ex) {
            throw ex;
        }
    },

    selectServicePagesByCaseId: async function (req, res, next) {
        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn
                .connect()

            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseId', sql.Int, req.query.caseId)
                .input('action', sql.VarChar, req.query.action)
                .execute('spGetServicePages')
            dbConn.close();

            data = [];

            var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data
            };
            return result;


        }
        catch (ex) {

            throw ex;
        }
    },

    getCaseDetailsByCaseId: async function (req, res, next) {
        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn
                .connect()

            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('caseId', sql.Int, req.query.caseId)
                .input('action', sql.VarChar, req.query.action)
                .execute('spGetCaseDetails')
            dbConn.close();

            data = {};

            var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordset[0] : data
            };
            return result;


        }
        catch (ex) {

            throw ex;
        }
    },

    getCaseDetailsByUserId: async function (req, res, next) {
        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn
                .connect()

            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('userId', sql.Int, req.query.userId)
                .input('action', sql.VarChar, req.query.action)
                .execute('spGetCaseDetailsByUserId')
            dbConn.close();

            data = [];

            var result = {
                status: 'Success',
                data: (recordSet.recordset.length > 0) ? recordSet.recordsets[0] : data
            };
            return result;


        }
        catch (ex) {

            throw ex;
        }
    },

    saveServicePages: async function (req, res, next) {

        try {
            var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
            await dbConn.connect()
            var request = await new sql.Request(dbConn);
            var recordSet = await request
                .input('servicePageId', sql.Int, req.body.servicePageId)
                .input('caseId', sql.Int, req.body.caseId)
                .input('serve', sql.VarChar, req.body.serve)
                .input('name', sql.VarChar, req.body.name)
                .input('recipient', sql.VarChar, req.body.recipient)
                .input('status', sql.VarChar, req.body.status)
                .input('affiliation', sql.VarChar, req.body.affiliation)
                .input('role', sql.VarChar, req.body.role)
                .input('email', sql.VarChar, req.body.email)
                .input('address', sql.VarChar, req.body.address)
                .input('action', sql.VarChar, req.body.action)
                .execute('spSaveServicePages')
            await dbConn.close();

            if (recordSet.recordset[0].errorMessage == 'Success') {
                var result = {

                    status: 'Success',
                    message: req.body.servicePageId == 0 ? 'Record Saved Successfully' : 'Record Updated Successfully',
                    servicePageId: recordSet.recordset[0].servicePageId,

                };

                return result;
            } else {
                var result = {
                    status: 'Error',
                    message: recordSet.recordset[0].errorMessage,
                };
                return result;
            }

        } catch (ex) {
            throw ex;
        }
    }, 

  deletePartyandAttachment: async function (req, res, next) {

        try {
    
          var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
          await dbConn.connect()
    
          var request = await new sql.Request(dbConn);
          var recordSet = await request
            .input('action', sql.VarChar, req.query.action)
            .input('Id', sql.Int, req.query.id)
            .execute('spDeletePartyAttachment')
          await dbConn.close()
          if (recordSet.recordset[0].errorMessage == 'Success') {
    
            var result = {
    
              status: 'Success',
              message: 'Record deleted successfully'
    
            };
            return result;
          } else {
            var result = {
              status: 'Error',
              message: "Error in delete operation"
            };
            return result;
          }
    
    
    
        } catch (ex) {
    
          throw ex;
        }
      },

}

module.exports = caseDetails;