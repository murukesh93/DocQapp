var objconfig = require('../config/appconfig')
var sql = require('mssql');
var objErrorLog = require('./errorLog');
var objCommon = require('./common');
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');
var objStripe = require('../dao/stripe')

var userDAO = {

  saveUser: async function (req, res, next) {

    try {

      var otpGenerator = require('otp-generator')
      var otp = otpGenerator.generate(6, { upperCase: false, specialChars: false, alphabets: false });

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()
      req.body.name = req.body.firstName + ' ' + req.body.lastName;
      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('userId', sql.Int, req.body.userId)
        .input('firstName', sql.VarChar, req.body.firstName)
        .input('lastName', sql.VarChar, req.body.lastName)
        .input('phone', sql.VarChar, req.body.phone)
        .input('email', sql.VarChar, req.body.email)
        .input('password', sql.VarChar, req.body.password)
        .input('userType', sql.VarChar, req.body.userType)
        .input('isEmailVerified', sql.Bit, req.body.isEmailVerified)
        .input('action', sql.VarChar, req.body.action)
        .input('otp', sql.VarChar, otp)
        .execute('spSaveUser')

      await dbConn.close();
      req.body.password = objCommon.decryptString(req.body.password);

      if (recordSet.recordset[0].errorMessage == 'Success') {
        if (req.body.action == "Add") {
          userRegistration(req.body.email, req.body.password, otp);
          req.body.userId = recordSet.recordset[0].userId;
          var objCustomer = objStripe.createCustomer(req, res, next);
        }

        var result = {

          status: 'Success',
          message: req.body.userId == 0 ? 'Record Saved Successfully.Verification code sent your registered email.Please activate your email account!' : 'Record Updated Successfully',
          userId: recordSet.recordset[0].userId,

        };

        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }

    } catch (ex) {

      throw ex;
    }
  },

  updatePassword: async function (req, res, next) {
    try {
      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()
      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('email', sql.VarChar, req.body.email)
        .input('oldPassword', sql.VarChar, req.body.oldPassword)
        .input('newPassword', sql.VarChar, req.body.newPassword)
        .execute('spUpdatePassword')

      await dbConn.close();
      if (recordSet.recordset[0].errorMessage == 'Success') {
        var result = {
          status: 'Success',
          message: 'Password Updated Successfully',
        };
        return result;
      }else{
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }
    } catch (ex) {

      throw ex;
    }
  },

  deleteSelectByUser: async function (req, res, next) {
    try {


      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('userId', sql.Int, req.query.userId)
        .input('action', sql.VarChar, req.query.action)
        .execute('spDeleteSelectByUser')

      dbConn.close();

      data = {};
      var result = {
        status: 'Success',
        data: (recordSet.recordset.length > 0) ? recordSet.recordset[0] : data
      };
      return result;


    }
    catch (ex) {

      throw ex;
    }
  },
  
  sigIn: async function (req, res, next) {
    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn
        .connect()
      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('email', sql.VarChar, req.body.email)
        .input('password', sql.VarChar, req.body.password)
        .execute('spLogin')

      await dbConn.close();

      if (recordSet.recordset.length > 0) {
        if (recordSet.recordset[0].isEmailVerified == 1) {
          data = {};
          var result = {
            status: 'Success',
            message: 'Login Successfull!.',
            data: recordSet.recordset[0],
          };
          return result;
        }
        else {
          var result = {
            status: 'Error',
            message: 'Please activate your email!'
          };
          return result;
        }


      } else {
        var result = {
          status: 'Error',
          message: 'Invalid username or password'
        };
        return result;
      }


    } catch (ex) {

      throw ex;
    }
  },

  verifyEmail: async function (req, res, next) {

    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await dbConn.connect()

      var request = await new sql.Request(dbConn);
      var recordSet = await request
        .input('email', sql.VarChar, req.body.email)
        .input('OTPValue', sql.VarChar, req.body.otp)
        .execute('spVerifyEmail')

      await dbConn.close();

      if (recordSet.recordset[0].errorMessage == 'Success') {

        var result = {

          status: 'Success',
          message: 'Email verified successfully!.',


        };
        return result;
      } else {
        var result = {
          status: 'Error',
          message: recordSet.recordset[0].errorMessage,
        };
        return result;
      }



    } catch (ex) {

      throw ex;
    }
  },

}

function userRegistration(email, password, otp) {
  try {
    var filepath = __dirname + '//views//emailtemplates//registration.html';
    filepath = filepath.replace('dao', '');
    filepath = path.normalize(filepath);
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        objErrorLog.saveLog('userRegistration', result)
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          email: email,
          password: password,
          verificationCode: otp
        };

        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(objconfig.fromEmail, email, 'Profile Registration', htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              objErrorLog.saveLog('userRegistration', result);
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message };
            objErrorLog.saveLog('userRegistration', result)
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    objErrorLog.saveLog('userRegistration', result)
    return (result);
  }


}

module.exports = userDAO;
