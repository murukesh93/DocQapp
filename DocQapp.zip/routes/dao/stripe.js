
var objConfig=require('../config/appconfig');
var stripe = require('stripe')(objConfig.stripeToken);
var objErrorLog = require('./errorLog');
var sql = require('mssql');
var objUserDAO=require('../dao/user');
var objconfig = require('../config/appconfig')

var stripeDAO={ 
 createCustomer: function(req,res,next){ 
            try{
    
                return new Promise( function(resolve, reject) {
    
                stripe.customers.create(
                    {
                      name: req.body.name,
                      phone: req.body.phone,
                      email: req.body.email
                    },
                    async function(err, customer) {  
                        if (err) {
                            var result = { status: 'Error', message: err.message };
                            objErrorLog.saveLog('createCustomer', result); 
                           return reject(result);
                        } else {
                            req.body.customerId=customer.id;
                            updateCustomerToken (req, res, next);
                            return  resolve({status:'Success',customerId: customer.id});

                        }
    
                    }
                  );
                }) 
    
        }
            catch(ex){
                 
                objErrorLog.saveLog('createCustomer', result);
                throw ex;
                
            }
        },  

  addCard: function(req,res,next){ 
        try{
    
            return new Promise(function(resolve, reject) {
    
                stripe.customers.createSource(
                    req.body.customerId,
                    {source: req.body.cardToken},
    
                function(err, card) {  
                    if (err) {
                        var result = { status: 'Error', message: err.message };
                        objErrorLog.saveLog('addCard', result);
                       return reject(result);
                    } else {
                        return  resolve({status:'Success',cardId: card.id});
                    }
    
                }
              );
            }) 
    
    }
        catch(ex){
            var result = { status: 'Error', message: ex.message };
            objErrorLog.saveLog('addCard', result);
            throw ex;
        }
    },

 listCard: function(req,res,next){ 
        try{
    
            return new Promise(function(resolve, reject) {
    
                stripe.customers.listSources(
                    req.query.customerId,
                    {object: 'card', limit: 10},
    
                function(err, card) {  
                    if (err) {
                        var result = { status: 'Error', message: err.message };
                        objErrorLog.saveLog('listCard', result);
                       return reject(result);
                    } else {
                        return  resolve({status:'Success',card: card});
                    }
    
                }
              );
            }) 
    
    }
        catch(ex){
            var result = { status: 'Error', message: ex.message };
            objErrorLog.saveLog('listCard', result);
            throw ex;
        }
    },

deleteCard: function(req,res,next){ 
        try{
    
            return new Promise(function(resolve, reject) {
    
                stripe.customers.deleteSource(
                   req.query.customerId,
                   req.query.cardId,
                    function(err, confirmation) 
                    {
                        if (err) {
                        var result = { status: 'Error', message: err.message };
                        objErrorLog.saveLog('deleteCard', result);
                       return reject(result);
                    } else {
                        return  resolve({status:'Success',message:'Card deleted successfully.'});
                    }
    
                    }
                  );
     
                }
              );
            
    
    }
        catch(ex){
            var result = { status: 'Error', message: ex.message };
            objErrorLog.saveLog('deleteCard', result);
            throw ex;
        }
    },

setDefaultCard: function(req,res,next){ 
        try{
    
            return new Promise(function(resolve, reject) {
                stripe.customers.update(
                    req.body.customerId,
                    {default_source: req.body.cardId},
                    function(err, customer) {
                        if (err) {
                            var result = { status: 'Error', message: err.message };
                            objErrorLog.saveLog('setDefaultCard', result);
                           return reject(result);
                        } else {
                            return  resolve({status:'Success',message:'Default card updated successfully.'});
                        }
                    }
                  ); 
     
                }
              );
            
    
    }
        catch(ex){
            var result = { status: 'Error', message: ex.message };
            objErrorLog.saveLog('setDefaultCard', result);
            throw ex;
        }
    },
    
createPayment: function(req,res,next){ 
        try{

            return new Promise(function(resolve, reject) {

                stripe.charges.create(
                    {
                      amount: req.body.amount * 100,
                      currency: 'usd',
                      //source: req.body.source,
                      description: req.body.description,
                      customer: req.body.customerId
                    },
                function(err, charge) {  
                    if (err) {
                        var result = { status: 'Error', message: err.message };
                        objErrorLog.saveLog('createPayment', result); 
                       return reject(result);
                    } else {
                        return  resolve({status:'Success',data: charge.id});
                    }

                }
              );
            }) 

    }
        catch(ex){
            var result = { status: 'Error', message: ex.message };
            objErrorLog.saveLog('createPayment', result);
            throw ex;
        }
    },  
    
}; 

async  function updateCustomerToken (req, res, next) {

    try {

      var dbConn = await new sql.ConnectionPool(objconfig.ConnectionString);
      await  dbConn.connect()
      
            var request = await new sql.Request(dbConn); 
           var recordSet= await  request 
           .input('userId', sql.Int, req.body.userId)
           .input('customerId', sql.VarChar, req.body.customerId)
           .query('update tblUser set userStripeId=@customerId where userId=@userId')
            
            await dbConn.close();

                // if (recordSet.recordset[0].errorMessage == 'Success') {
            
                //   var result = {

                //     status: 'Success',
                //     message: 'Email verified successfully!.',
                    

                //   }; 
                //   return result;
                // } else {
                //   var result = {
                //     status: 'Error',
                //     message: recordSet.recordset[0].errorMessage,
                //   };
                //   return result;
                // }
           
                return "Success";

    }  catch(ex){ 
      
      throw ex;
    }
  }


module.exports=stripeDAO;