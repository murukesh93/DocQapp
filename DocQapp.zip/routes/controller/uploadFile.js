/**
* @swagger 
 
* /uploadFile/uploadFile:
*   post:
*     tags:
*       - uploadFile
*     name: Upload a file
*     summary: Upload a file to azure bucket
*     security:
*       - bearerAuth: []
*     consumes:
*       -  multipart/form-data
*     produces:
*       - application/json
*     parameters: 
*       - in: formData
*         name: file
*         type: file
*         required: true 
 *       - in: query
 *         name: userId 
 *         type: integer
*         required: true 
*     responses:
*       200:
*        description:  Return Filepath
*       400:
*        description: Invalid Token key. 
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 



  /uploadFile/accessFile:
*   post:
*     tags:
*       - uploadFile
*     name: uploadFile
*     summary: To access the blob storage file
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             filepath:
*               type: string

*
*         required:
*           - filepath

*
*     responses:
*       200:
*         description: Filepath with token
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*

 
*/


var path = require('path');
var objFileUpload=require('../dao/uploadFile'); 
var express = require('express');
const router = express.Router();
var jwtAuth=require('../dao/jwt');
var multiparty = require ('connect-multiparty')
multipartyMiddleware =  multiparty();
router.use(multipartyMiddleware);
var fs = require('fs'); 
var storage = require("@azure/storage-blob")
var objconfig=require('../config/appconfig');

router.post('/uploadFile', async  function(req, res,next) {
  try {
   
    console.log(req.files.file);
    var result = await objFileUpload.uploadFile(req,res,next) ; 
    if (result.status === 'Error') {
     
      return res.status(500)  .json(result);
    } else { 
      
      return res.status(200).json(result);
    }
 
}  catch (excb1) {

  var result = { status: 'Error', message: excb1.message };
 return res.status(500).json(result);
}
});

 
router.post('/accessFile',async  function(req, res,next) {
  try {
    
    const accountname =objconfig.accountName;
    const key = objconfig.accountKey;
    const cerds = new storage.StorageSharedKeyCredential(accountname,key);
    const baseurl=`https://${accountname}.blob.core.windows.net`;
    const blobServiceClient = new storage.BlobServiceClient(baseurl,cerds);
    const containerName=objconfig.containerName;
    const client =blobServiceClient.getContainerClient(containerName)
    const blobName=req.body.filepath.replace(baseurl+"/"+containerName+"/",""); 
    const blobClient = client.getBlobClient(blobName); 
    const blobSAS = storage.generateBlobSASQueryParameters({
      containerName, 
      blobName, 
      permissions: storage.BlobSASPermissions.parse("racwd"), 
      startsOn: new Date(),
      expiresOn: new Date(new Date().valueOf() + 86400)
    },
    cerds 
  ).toString();

    const sasUrl= blobClient.url+"?"+blobSAS;
    var result={
      filepath: sasUrl
    }
    return res.status(200).json(result);
 
}  catch (excb1) {

  var result = { status: 'Error', message: excb1.message };
 return res.status(500).json(result);
}
});

 

    module.exports = router; 