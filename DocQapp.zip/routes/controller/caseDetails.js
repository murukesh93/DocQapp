/**
* @swagger 
*  /case/saveCaseDetails:
*   post:
*     tags:
*       - case
*     name: case
*     summary: To save a case Details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             appellateCourt:
*               type: string
*             judicialCourt:
*               type: string
*             caseName:
*               type: string
*             caseNumberPending:
*               type: string
*             caseInitiation:
*               type: string
*             pleadinginExistingCase:
*               type: string
*             fileMultipleCases:
*               type: string
*             fileSameDocument:
*               type: string
*             multipleCases:
*               type: string
*             proposedOrder:
*               type: string
*             caseDescription:
*               type: string
*             caseStatus:
*               type: string
*             userId:
*               type: integer
*             courtId:
*               type: integer
*             countryId:
*               type: integer
*             divisionId:
*               type: integer
*             caseTypeId:
*               type: integer
*             subTypeId:
*               type: integer

*         required:
*           - appellateCourt
*           - judicialCourt
*           - caseName
*           - caseNumberPending
*           - caseInitiation
*           - pleadinginExistingCase
*           - fileMultipleCases
*           - fileSameDocument
*           - multipleCases
*           - proposedOrder
*           - caseDescription
*           - caseStatus
*           - userId
*           - email
*           - courtId
*           - countryId
*           - divisionId
*           - subTypeId
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*

 /case/updateCaseDetails:
*   put:
*     tags:
*       - case
*     name: case
*     summary: To update a case Details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             caseId:
*               type: integer
*             appellateCourt:
*               type: string
*             judicialCourt:
*               type: string
*             caseName:
*               type: string
*             caseNumberPending:
*               type: string
*             caseInitiation:
*               type: string
*             pleadinginExistingCase:
*               type: string
*             fileMultipleCases:
*               type: string
*             fileSameDocument:
*               type: string
*             multipleCases:
*               type: string
*             proposedOrder:
*               type: string
*             caseDescription:
*               type: string
*             caseStatus:
*               type: string
*             userId:
*               type: integer
*             courtId:
*               type: integer
*             countryId:
*               type: integer
*             divisionId:
*               type: integer
*             caseTypeId:
*               type: integer
*             subTypeId:
*               type: integer

*         required:
*           - caseId
*
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
  /case/getCaseDetailsByCaseId:
 *   get:
 *     tags:
 *       - case
 *     name: case
 *     summary: To select a caseDetails by caseId .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: caseId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
 
    /case/getCaseDetailsByUserId:
 *   get:
 *     tags:
 *       - case
 *     name: case
 *     summary: To select a caseDetails by userId .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 

  /case/saveCaseAttachments:
*   post:
*     tags:
*       - case
*     name: case
*     summary: To save a case  attachment Details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             filePath:
*               type: string
*             fileName:
*               type: string
*             documentId:
*               type: integer
*             caseId:
*               type: integer
*             fileDescription:
*               type: string
*             fileOrder:
*               type: integer

*         required:
*           - filePath
*           - fileName
*           - documentId
*           - caseId
*           - fileDescription
*           - fileOrder
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
  /case/updateCaseAttachments:
*   put:
*     tags:
*       - case
*     name: case
*     summary: To update a case attachments
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             caseAttachmentsId:
*               type: integer
*             filePath:
*               type: string
*             fileName:
*               type: string
*             documentId:
*               type: integer
*             caseId:
*               type: integer
*             fileDescription:
*               type: string
*             fileOrder:
*               type: integer

*         required:
*           - caseAttachmentsId
*
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
  
    /case/getCaseAttachmentByCaseId:
 *   get:
 *     tags:
 *       - case
 *     name: case
 *     summary: To select a case attachment details by caseId .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: caseId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
  /case/savePartyInformation:
*   post:
*     tags:
*       - case
*     name: case
*     summary: To save a case  party Information Details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             partyName:
*               type: string
*             caseId:
*               type: integer
*             phoneNumber:
*               type: string
*             address:
*               type: string
*             email:
*               type: string
*             type:
*               type: string

*         required:
*           - caseId
*           - partyName
*           - phoneNumber
*           - email
*           - address

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
 
   /case/updatePartyInformation:
*   put:
*     tags:
*       - case
*     name: case
*     summary: To update a case party information
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             partyInformationId:
*               type: integer
*             partyName:
*               type: string
*             phoneNumber:
*               type: string
*             caseId:
*               type: integer
*             email:
*               type: string
*             address:
*               type: string
*             type:
*               type: string

*         required:
*           - partyInformationId
*
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*

  /case/getpartyInformationByCaseId:
 *   get:
 *     tags:
 *       - case
 *     name: case
 *     summary: To select a party information  by caseId .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: caseId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
  /case/saveServicePageDetails:
*   post:
*     tags:
*       - case
*     name: case
*     summary: To save a service page Details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             caseId:
*               type: integer
*             serve:
*               type: string
*             phoneNumber:
*               type: string
*             name:
*               type: string
*             recipient:
*               type: string
*             status:
*               type: string
*             affiliation:
*               type: string
*             role:
*               type: string
*             email:
*               type: string
*             address:
*               type: string

*         required:
*           - caseId
*           - email
*           - status
*           - recipient
*           - address
*           - role
*           - affiliation

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
   /case/updateServicePageDetails:
*   put:
*     tags:
*       - case
*     name: case
*     summary: To update a service page details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             servicePageId:
*               type: integer
*             serve:
*               type: string
*             name:
*               type: string
*             caseId:
*               type: integer
*             address:
*               type: string
*             status:
*               type: string
*             affiliation:
*               type: string
*             role:
*               type: string
*             recipient:
*               type: string

*         required:
*           - servicePageId
*
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
   
    /case/getServicePagesByCaseId:
 *   get:
 *     tags:
 *       - case
 *     name: case
 *     summary: To select a service pages by caseId .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: caseId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 
   /case/deletePartyandAttachment:
 *   delete:
 *     tags:
 *       - case
 *     name: case
 *     summary: To delete a Party or attachment details by Id .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: id
 *         type: integer
 *         required: true
 *       - in: query
 *         name: action
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
*/
var express = require('express');
const router = express.Router();
var objCase = require('../dao/caseDetails');
var jwtAuth = require('../dao/jwt');

router.post('/saveCaseDetails', jwtAuth.VerifyToken, async function (req, res, next) {
  try { 

    
    

    if (req.body.caseInitiation == '' || req.body.caseInitiation == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseInitiation is required!' });
    }

    if (req.body.pleadinginExistingCase == '' || req.body.pleadinginExistingCase == undefined) {
      return res.status(403).json({ status: 'Error', message: 'PleadinginExistingCase is required!' });
    }

  
    if (req.body.userId == '' || req.body.userId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
    }

    if (req.body.courtId == '' || req.body.courtId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CourtId is required!' });
    }

    if (req.body.countryId == '' || req.body.countryId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CountryId is required!' });
    }
    if (req.body.divisionId == '' || req.body.divisionId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'DivisionId is required!' });
    }
  
    if (req.body.subTypeId == '' || req.body.subTypeId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'SubTypeId is required!' });
    }

    req.body.action = 'Add';
    req.body.caseId = 0;
    var result = await objCase.saveCaseDetails(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.put('/updateCaseDetails',  jwtAuth.VerifyToken,async function (req, res, next) {
  try {

    if (req.body.caseId == '' || req.body.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }

    req.body.action = 'Edit';
    var result = await objCase.saveCaseDetails(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/saveCaseAttachments', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.filePath == '' || req.body.filePath == undefined) {
      return res.status(403).json({ status: 'Error', message: 'FilePath is required!' });
    }
    if (req.body.fileName == '' || req.body.fileName == undefined) {
      return res.status(403).json({ status: 'Error', message: 'FileName is required!' });
    }
    if (req.body.documentId == '' || req.body.documentId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'DocumentId is required!' });
    }
    if (req.body.caseId == '' || req.body.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }

    if (req.body.fileDescription == '' || req.body.fileDescription == undefined) {
      return res.status(403).json({ status: 'Error', message: 'FileDescription is required!' });
    }

    if (req.body.fileOrder == '' || req.body.fileOrder == undefined) {
      return res.status(403).json({ status: 'Error', message: 'FileOrder  is required!' });
    }

    req.body.action = 'Add';
    req.body.caseAttachmentsId = 0;
    var result = await objCase.saveCaseAttachments(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.put('/updateCaseAttachments', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.caseAttachmentsId == '' || req.body.caseAttachmentsId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseAttachmentsId is required!' });
    }

    req.body.action = 'Edit';
    var result = await objCase.saveCaseAttachments(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.get('/getCaseAttachmentByCaseId', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.caseId == '' || req.query.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    req.query.action = 'Select';
    var result = await objCase.selectCaseAttachmentByCaseId(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.get('/getpartyInformationByCaseId', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.caseId == '' || req.query.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    req.query.action = 'Select';
    var result = await objCase.selectPartyInformationByCaseId(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/savePartyInformation', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.caseId == '' || req.body.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    if (req.body.partyName == '' || req.body.partyName == undefined) {
      return res.status(403).json({ status: 'Error', message: 'PartyName is required!' });
    }
    if (req.body.phoneNumber == '' || req.body.phoneNumber == undefined) {
      return res.status(403).json({ status: 'Error', message: 'PhoneNumber is required!' });
    }
    if (req.body.address == '' || req.body.address == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Address is required!' });
    }

    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }

    req.body.action = 'Add';
    req.body.partyInformationId = 0;
    var result = await objCase.savePartyInformation(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.put('/updatePartyInformation', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.partyInformationId == '' || req.body.partyInformationId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'partyInformationId is required!' });
    }

    req.body.action = 'Edit';
    var result = await objCase.savePartyInformation(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/saveServicePageDetails', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.caseId == '' || req.body.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    if (req.body.serve == '' || req.body.serve == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Serve is required!' });
    }
    if (req.body.name == '' || req.body.name == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Name is required!' });
    }
    if (req.body.recipient == '' || req.body.recipient == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Recipient is required!' });
    }
    if (req.body.status == '' || req.body.status == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Status is required!' });
    }
    if (req.body.affiliation == '' || req.body.affiliation == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Affiliation is required!' });
    }
    if (req.body.role == '' || req.body.role == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Role is required!' });
    }
    if (req.body.address == '' || req.body.address == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Address is required!' });
    }

    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }

    req.body.action = 'Add';
    req.body.servicePageId = 0;
    var result = await objCase.saveServicePages(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.put('/updateServicePageDetails', jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.servicePageId == '' || req.body.servicePageId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'ServicePageId is required!' });
    }

    req.body.action = 'Edit';
    var result = await objCase.saveServicePages(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.get('/getServicePagesByCaseId', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.caseId == '' || req.query.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    req.query.action = 'Select';
    var result = await objCase.selectServicePagesByCaseId(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.get('/getCaseDetailsByCaseId', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.caseId == '' || req.query.caseId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'CaseId is required!' });
    }
    req.query.action = 'Select';
    var result = await objCase.getCaseDetailsByCaseId(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.get('/getCaseDetailsByUserId', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.userId == '' || req.query.userId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
    }
    req.query.action = 'Select';
    var result = await objCase.getCaseDetailsByUserId(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});


router.delete('/deletePartyandAttachment', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.id == '' || req.query.id == undefined) {
      return res.status(403).json({ status: 'Error', message: 'id is required!' });
    }
    else if (req.query.action == '' || req.query.action == undefined) {
      return res.status(403).json({ status: 'Error', message: 'action is required!' });
    }
    var result = await objCase.deletePartyandAttachment(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }


  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});


module.exports = router;