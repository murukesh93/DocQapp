
/**
* @swagger 
*  /user/signUp:
*   post:
*     tags:
*       - user
*     name: user
*     summary: To signup a user
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             lastName:
*               type: string
*             email:
*               type: string
*             password:
*               type: string
*             phone:
*               type: string

*         required:
*           - firstName
*           - email
*           - password
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

   /user/updateProfile:
*   post:
*     tags:
*       - user
*     name: user
*     summary: To update a user profile details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             firstName:
*               type: string
*             lastName:
*               type: string
*             userId:
*               type: integer
*             phone:
*               type: string

*         required:
*           - firstName
*           - userId
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


  /user/verifyEmail:
*   post:
*     tags:
*       - user
*     name: user
*     summary: To verify the user email
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             otp:
*               type: string

*
*         required:
*           - email
*           - otp

*
*     responses:
*       200:
*         description: Login successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*

 * /user/getProfileDetail:
 *   get:
 *     tags:
 *       - user
 *     name: user
 *     summary: To select particular user details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /user/sigIn:
*   post:
*     tags:
*       - user
*     name: user
*     summary: user login
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             password:
*               type: string

*
*         required:
*           - email
*           - password

*
*     responses:
*       200:
*         description: Login successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*

* /user/forgetPassword:
*   post:
*     tags:
*       - user
*     name: user
*     summary: Update a password with otp value
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             password:
*               type: string
*             otpValue:
*               type: string
*         required:
*           - email
*           - newPassword
*           - otpValue
*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /user/generateOTP:
*   post:
*     tags:
*       - user
*     name: user
*     summary: To send otp to update a password 
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             otpType:
*               type: string  
*         required:
*           - email
*           - otpType
*     responses:
*       200:
*         description: Otp Send successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

  /user/updatePassword:
*   put:
*     tags:
*       - user
*     name: user
*     summary: To send otp to update a password 
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     produces:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             oldPassword:
*               type: string  
*             newPassword:
*               type: string  
*         required:
*           - email
*           - oldPassword
*           - newPassword
*     responses:
*       200:
*         description: Password updated Successfully.
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*/

var express = require('express');
const router = express.Router();
var objUserDAO = require('../dao/user');
const config = require('../config/appconfig');
const objCommon = require('../dao/common');
var objErrorLog = require('../dao/errorLog');
var jwt = require('jsonwebtoken');
var jwtAuth = require('../dao/jwt');
var otpGenerator = require('otp-generator')
var path = require('path');
var handlebars = require('handlebars');
var fs = require('fs');

router.post('/signUp', async function (req, res, next) {
  try {
    if (req.body.firstName == '' || req.body.firstName == undefined) {
      return res.status(403).json({ status: 'Error', message: 'firstName is required!' });
    }

    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'email is required!' });
    }
    if (req.body.password == '' || req.body.password == undefined) {
      return res.status(403).json({ status: 'Error', message: 'password is required!' });
    }

    console.log(req.body.firstName);
    req.body.userId = 0;
    req.body.action = 'Add';
    req.body.isEmailVerified = 0;
    req.body.password = objCommon.encryptString(req.body.password);


    var result = await objUserDAO.saveUser(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }

});

router.post('/updateProfile', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.body.firstName == '' || req.body.firstName == undefined) {
      return res.status(403).json({ status: 'Error', message: 'FirstName is required!' });
    }
    if (req.body.userId <= 0 || req.body.userId == '' || req.body.userId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'userId is required!' });
    }


    req.body.action = 'Edit';
    req.body.password = objCommon.encryptString(req.body.password);

    var result = await objUserDAO.saveUser(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }

});

router.put('/updatePassword',jwtAuth.VerifyToken, async function (req, res, next) {
  try {

    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }
    if (req.body.oldPassword == '' || req.body.oldPassword == undefined) {
      return res.status(403).json({ status: 'Error', message: 'OldPassword is required!' });
    }
    if (req.body.newPassword == '' || req.body.newPassword == undefined) {
      return res.status(403).json({ status: 'Error', message: 'NewPassword is required!' });
    }
    req.body.oldPassword = objCommon.encryptString(req.body.oldPassword);
    req.body.newPassword = objCommon.encryptString(req.body.newPassword);

    var result = await objUserDAO.updatePassword(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});


router.get('/getProfileDetail', jwtAuth.VerifyToken, async function (req, res, next) {
  try {
    if (req.query.userId == '' || req.query.userId == undefined) {
      return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
    }
    req.query.action = 'Select';
    var result = await objUserDAO.deleteSelectByUser(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/sigIn', async function (req, res, next) {

  try {
    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }
    if (req.body.password == '' || req.body.password == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Password is required!' });
    }


    req.body.password = objCommon.encryptString(req.body.password);
    var result = await objUserDAO.sigIn(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      var token = jwt.sign(

        {
          userRole: req.body.userRole,
          userId: result.data.userId,
          email: result.data.email,
          iat: Math.floor(Date.now() / 1000)
        },
        config.JWTSecretKey,
        { expiresIn: '24h' }
      );

      return res
        .set({ accesstoken: objCommon.encryptString(token) })
        .header('Access-Control-Expose-Headers', 'accesstoken')
        .status(200)
        .json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/verifyEmail', async function (req, res, next) {

  try {
    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }
    if (req.body.otp == '' || req.body.otp == undefined) {
      return res.status(403).json({ status: 'Error', message: 'otp is required!' });
    }

    var result = await objUserDAO.verifyEmail(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {

      return res
        .status(200)
        .json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/forgetPassword', async function (req, res, next) {
  try {

    if (req.body.email == '' || req.body.email == undefined || req.body.email == 0) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }
    if (req.body.password == '' || req.body.password == undefined || req.body.password == 0) {
      return res.status(403).json({ status: 'Error', message: 'Password is required!' });
    }
    if (req.body.otpValue == '' || req.body.otpValue == undefined) {
      return res.status(403).json({ status: 'Error', message: 'OtpValue is required!' });
    }
    req.body.password = objCommon.encryptString(req.body.password);
    req.body.otpType = "Forget Password"
    var result = await objCommon.forgetPassword(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

router.post('/generateOTP', async function (req, res, next) {
  try {
    var otp = otpGenerator.generate(6, { upperCase: false, specialChars: false, alphabets: false });

    if (req.body.email == '' || req.body.email == undefined) {
      return res.status(403).json({ status: 'Error', message: 'Email is required!' });
    }
    else if (req.body.otpType == '' || req.body.otpType == undefined) {
      return res.status(403).json({ status: 'Error', message: 'OtpType is required!' });
    }
    req.body.otp = otp;
    // Forget Password  //Verify Email

    var result = await objCommon.generateOTP(req, res, next);
    if (result.status === 'Error') {
      return res.status(500).json(result);
    } else {
      emailToOTP(req.body.email, req.body.otp, req.body.otpType)
      return res.status(200).json(result);
    }

  } catch (ex) {
    var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  }
});

function emailToOTP(email, otp, otpType) {
  try {
    var filepath = __dirname + '//views//emailtemplates//otp.html';
    filepath = filepath.replace('controller', '');
    filepath = path.normalize(filepath);

    console.log("filepath ", filepath)
    fs.readFile(filepath, { encoding: 'utf-8' }, function (err, html) {
      if (err) {
        var result = { status: 'Error', message: err.message };
        objErrorLog.saveLog('emailToOTP', result)
        return (result);
      } else {
        var template = handlebars.compile(html);
        var replacements = {
          otpType: otpType,
          otp: otp,
          heading: otpType
        };

        var htmlToSend = template(replacements);
        var objSendEmail = objCommon.sendEmail(config.fromEmail, email, otpType + " OTP", htmlToSend);
        objSendEmail.then(
          function (result) {
            if (result.status === 'Error') {
              objErrorLog.saveLog('emailToOTP', result);
              return (result);
            } else {
              return (result);
            }
          },
          function (err) {
            var result = { status: 'Error', message: err.message };
            objErrorLog.saveLog('emailToOTP', result)
            return (result);
          }
        );


      }
    });

  }
  catch (ex) {
    var result = { status: 'Error', message: ex.message };
    objErrorLog.saveLog('emailToOTP', result)
    return (result);
  }


}


module.exports = router;