/**
 * @swagger 
 * 
 * /test/getDate:
 *   get:
 *     tags:
 *       - test
 *     name: test
 *     summary: To get current db date time.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 */

var express = require('express');
const router = express.Router();
var objTest = require('../dao/test');

router.get('/getDate', async function (req, res, next) {
    try {
        var result = await objTest.getDate(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
})

module.exports = router;