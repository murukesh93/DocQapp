/**
* @swagger 

*  /efile/createFolder:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To create a new folder
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             folderName:
*               type: string
*             userId:
*               type: integer
*             tagId:
*               type: integer
*             parentId:
*               type: integer

*         required:
*           - userId
*           - folderName
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


  /efile/updateFolder:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To update a existing folder
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             folderName:
*               type: string
*             folderId:
*               type: integer
*             userId:
*               type: integer
*             tagId:
*               type: integer
*             parentId:
*               type: integer

*         required:
*           - folderName
*           - folderId
*
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


  /efile/createDocument:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To create a document in particular folder
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             tagId:
*               type: integer
*             folderId:
*               type: integer
*             userId:
*               type: integer
*             description:
*               type: string
*             fileSize:
*               type: string
*             fileName:
*               type: string
*             fileType:
*               type: string
*             filePath:
*               type: string

*         required:
*           - userId
*           - folderId
*           - filePath
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


  /efile/updateDocument:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To update a document in particular folder
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties: 
*             documentId:
*               type: integer
*             tagId:
*               type: integer
*             folderId:
*               type: integer
*             description:
*               type: string
*             fileSize:
*               type: string
*             fileName:
*               type: string
*             fileType:
*               type: string
*             filePath:
*               type: string
*             userId:
*               type: integer

*         required:
*           - userId
*           - folderName
*           - filePath
*     responses:
*       200:
*         description: Record updated successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


 * /efile/getFolderDocument:
 *   get:
 *     tags:
 *       - efile
 *     name: efile
 *     summary: Get list of all folders and files
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: folderName
 *         type: string
 *       - in: query
 *         name: userId
 *         type: integer
 *       - in: query
 *         name: folderId
 *         type: integer
 *       - in: query
 *         name: tagName
 *         type: string
 *       - in: query
 *         name: folderTagName
 *         type: string
 *       - in: query
 *         name: folderTagId
 *         type: integer
 *       - in: query
 *         name: fileName
 *         type: string
 *       - in: query
 *         name: columnName
 *         type: string
 *       - in: query
 *         name: orderBy
 *         type: string
 
 *     responses:
 *       200:
 *        description: Return folder object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *

 * /efile/deleteFolderDocument:
 *   delete:
 *     tags:
 *       - efile
 *     name: efile
 *     summary: To delete the folders or files
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: folderId
 *         type: string
 *       - in: query
 *         name: documentId
 *         type: string
 
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
 * 
 /efile/signUp:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To signup a efileuser
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             password:
*               type: string
*             namePrefix:
*               type: string
*             firstName:
*               type: string
*             middleName:
*               type: string
*             lastName:
*               type: string
*             nameSuffix:
*               type: string
*             email:
*               type: string
*             phone:
*               type: string
*             dob:
*               type: string
*             country:
*               type: string
*             state:
*               type: string
*             city:
*               type: string
*             street:
*               type: string
*             postalCode:
*               type: string
*             departments:
*               type: array
*               items:
*                   type: string
*             individuationTag:
*               type: string
*             userRole:
*               type: string

*         required:
*           - firstName
*           - email
*           - password
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

   /efile/updateProfile:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To update a efileuser profile details
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             efileId:
*               type: integer
*             userId:
*               type: integer
*             namePrefix:
*               type: string
*             firstName:
*               type: string
*             middleName:
*               type: string
*             lastName:
*               type: string
*             nameSuffix:
*               type: string
*             phone:
*               type: string
*             dob:
*               type: string
*             country:
*               type: string
*             state:
*               type: string
*             city:
*               type: string
*             street:
*               type: string
*             postalCode:
*               type: string
*             departments:
*               type: string
*             individuationTag:
*               type: string
*             userRole:
*               type: string

*         required:
*           - firstName
*           - userId
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
 * /efile/getProfileDetail:
 *   get:
 *     tags:
 *       - efile
 *     name: efile
 *     summary: To select particular efileuser details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: efileId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /efile/sigIn:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: efileuser login
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             email:
*               type: string
*             password:
*               type: string

*
*         required:
*           - email
*           - password

*
*     responses:
*       200:
*         description: Login successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error.

 * /efile/getSecurityQuestion:
 *   get:
 *     tags:
 *       - efile
 *     name: efile
 *     summary: To get Security Question.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 * 
 /efile/saveSecurityQuestionAnswer:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To create a  Security Question Answer
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             answer:
*               type: array
*               items:
*                   type: object
*                   properties:
*                      securityQuestionId:
*                        type: integer
*                      answer :
*                       type: string
*         required:
*           - userId
*           - answer
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

 /efile/CheckValidateSecurityQuestion:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: To validate security question answer
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             answer:
*               type: array
*               items:
*                   type: object
*                   properties:
*                      securityQuestionId:
*                        type: integer
*                      answer :
*                       type: string
*         required:
*           - userId
*           - answer
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /efile/forgetPassword:
*   post:
*     tags:
*       - efile
*     name: efile
*     summary: Update a password 
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             password:
*               type: string
*            
*         required:
*           - userId
*           - password
*     responses:
*       200:
*         description: Password updated successfully
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


*/

var express = require('express');
const router = express.Router();
var objEfileDAO = require('../dao/efile');
var jwtAuth = require('../dao/jwt'); 
const objCommon = require('../dao/common');
var jwt = require('jsonwebtoken');
var jwtAuth = require('../dao/jwt');
const config = require('../config/appconfig');

router.post('/createFolder', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (req.body.folderName == '' || req.body.folderName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'folderName is required!' });
        }
         
        if (req.body.userId == '' || req.body.userId == undefined ||  req.body.userId<=0 ) {
            return res.status(403).json({ status: 'Error', message: 'userId is required!' });
        }  
        

        req.body.folderId = 0;
        req.body.action = 'Add';

        var result = await objEfileDAO.saveFolder(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.post('/updateFolder', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (req.body.folderName == '' || req.body.folderName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'folderName is required!' });
        }
         
        if (req.body.folderId == '' || req.body.folderId == undefined ||  req.body.folderId<=0 ) {
            return res.status(403).json({ status: 'Error', message: 'folderId is required!' });
        }  
         
        req.body.action = 'Edit';

        var result = await objEfileDAO.saveFolder(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});

router.post('/createDocument', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        // if (req.body.folderId == '' || req.body.folderId == undefined || req.body.folderId <=0) {
        //     return res.status(403).json({ status: 'Error', message: 'folderId is required!' });
        // }
         
        if (req.body.userId == '' || req.body.userId == undefined ||  req.body.userId<=0 ) {
            return res.status(403).json({ status: 'Error', message: 'userId is required!' });
        } 
        if (req.body.fileName == '' || req.body.fileName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'fileName is required!' });
        }
        if (req.body.filePath == '' || req.body.filePath == undefined) {
            return res.status(403).json({ status: 'Error', message: 'filePath is required!' });
        }
         
        req.body.documentId = 0;
        req.body.action = 'Add';

        var result = await objEfileDAO.saveDocument(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.post('/updateDocument', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (req.body.fileName == '' || req.body.fileName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'fileName is required!' });
        }
         
        if (req.body.documentId == '' || req.body.documentId == undefined ||  req.body.documentId<=0 ) {
            return res.status(403).json({ status: 'Error', message: 'documentId is required!' });
        } 
        if (req.body.filePath == '' || req.body.filePath == undefined) {
            return res.status(403).json({ status: 'Error', message: 'filePath is required!' });
        } 
         
        req.body.action = 'Edit';

        var result = await objEfileDAO.saveDocument(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});

router.get('/getFolderDocument', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
         
        var result = await objEfileDAO.getFolderDocument(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.delete('/deleteFolderDocument', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        
        var result = await objEfileDAO.deleteFolderDocument(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.post('/signUp', async function (req, res, next) {
    try {
        if (req.body.firstName == '' || req.body.firstName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'firstName is required!' });
        }
         
        if (req.body.password == '' || req.body.password == undefined) {
            return res.status(403).json({ status: 'Error', message: 'password is required!' });
        }  

        req.body.efileId = 0;
        req.body.action = 'Add'; 
        req.body.id = null;
        req.body.password = objCommon.encryptString(req.body.password);

        var result = await objEfileDAO.saveEfileUser(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.post('/updateProfile', async function (req, res, next) {
    try {
        //if (req.body.userId <= 0 || req.body.userId == '' || req.body.userId == undefined) {
          // return res.status(403).json({ status: 'Error', message: 'userId is required!' });
       // }
        if (req.body.efileId <= 0 || req.body.efileId == '' || req.body.efileId == undefined) {
            return res.status(403).json({ status: 'Error', message: 'efileId is required!' });
        }
       
        req.body.action = 'Edit'; 
        req.body.password = objCommon.encryptString(req.body.password);

        var result = await objEfileDAO.saveEfileUser(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.get('/getProfileDetail', async function (req, res, next) {
    try {
        if (req.query.efileId <= 0 || req.query.efileId == undefined) {
            return res.status(403).json({ status: 'Error', message: 'efileId is required!' });
        }
        req.query.action = 'Select';
        var result = await objEfileDAO.selectEfileUser(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.post('/sigIn', async  function (req, res, next) {
    
    try {
        if (req.body.email == '' || req.body.email == undefined) {
            return res.status(403).json({ status: 'Error', message: 'Email is required!' });
        }
        if (req.body.password == '' || req.body.password == undefined) {
            return res.status(403).json({ status: 'Error', message: 'Password is required!' });
        }
    
   
    req.body.password=objCommon.encryptString(req.body.password);
           var result = await objEfileDAO.sigIn(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
          } else { 
              console.log(result.data)
            var token = jwt.sign(
                       
                { 
                  userRole: req.body.userRole,
                  userId: result.data.userId,
                  email: result.data.email,
                  iat: Math.floor(Date.now() / 1000)
                },
                config.JWTSecretKey,
                { expiresIn: '24h' }
              );
            
              return res
                .set({ accesstoken: objCommon.encryptString(token) })
                .header('Access-Control-Expose-Headers', 'accesstoken')
                .status(200)
                .json(result);
          }
       
      }  catch (ex) {
        var result = { status: 'Error', message: ex.message };
       return res.status(500).json(result);
      }
});

router.get('/getSecurityQuestion', async function (req, res, next) {
        try {
           
            var result = await objEfileDAO.selectSecurityQuestion(req, res, next);
            if (result.status === 'Error') {
                return res.status(500).json(result);
            } else {
                return res.status(200).json(result);
            }
    
        } catch (ex) {
            var result = { status: 'Error', message: ex.message };
            return res.status(500).json(result);
        }
});
    
router.post('/saveSecurityQuestionAnswer',async  function (req, res, next) {
        
        try {
           
            if (req.body.userId == 0 || req.body.userId == undefined) {
                return res.status(403).json({ status: 'Error', message: 'userId is required!' });
            }
            if (req.body.answer == '' || req.body.answer == undefined) {
                return res.status(403).json({ status: 'Error', message: 'answer is required!' });
            }
           
               var result = await objEfileDAO.saveSecurityQuestionAnswer(req, res, next);
            if (result.status === 'Error') {
                return res.status(500).json(result);
              } else { 
                return res.status(200).json(result);
              }
           
          }  catch (ex) {
            var result = { status: 'Error', message: ex.message };
           return res.status(500).json(result);
          }
});
router.post('/CheckValidateSecurityQuestion',async function (req, res, next) {
    try {
  
      if (req.body.userId == '' || req.body.userId == undefined || req.body.userId == 0) {
        return res.status(403).json({ status: 'Error', message: 'userId is required!' });
      }
      if (req.body.answer == '' || req.body.answer == undefined || req.body.answer == 0) {
        return res.status(403).json({ status: 'Error', message: 'answer is required!' });
      }
      
      req.body.password=objCommon.encryptString(req.body.password);
      var result = await objEfileDAO.CheckValidateSecurityQuestion(req, res, next);
      if (result.status === 'Error') {
        return res.status(500).json(result);
      } else { 
        return res.status(200).json(result);
      }
   
  }  catch (ex) {
    var result = { status: 'Error', message: ex.message };
   return res.status(500).json(result);
  }
  });     
    
router.post('/forgetPassword',async function (req, res, next) {
    try {
  
      if (req.body.userId == '' || req.body.userId == undefined || req.body.userId == 0) {
        return res.status(403).json({ status: 'Error', message: 'userId is required!' });
      }
      if (req.body.password == '' || req.body.password == undefined || req.body.password == 0) {
        return res.status(403).json({ status: 'Error', message: 'Password is required!' });
      }
      
      req.body.password=objCommon.encryptString(req.body.password);
      var result = await objEfileDAO.forgetPassword(req, res, next);
      if (result.status === 'Error') {
        return res.status(500).json(result);
      } else { 
        return res.status(200).json(result);
      }
   
  }  catch (ex) {
    var result = { status: 'Error', message: ex.message };
   return res.status(500).json(result);
  }
  });     


module.exports = router;