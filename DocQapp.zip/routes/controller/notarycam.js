/**
* @swagger 
*  /notarycam/signUp:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: To signup a user
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             departments:
*               type: array
*               items:
*                   type: string
*             email:
*               type: string
*             namePrefix:
*               type: string
*             firstName:
*               type: string
*             middleName:
*               type: string
*             lastName:
*               type: string
*             nameSuffix:
*               type: string
*             phone:
*               type: string
*             dateOfBirth:
*               type: string
*             country:
*               type: string
*             state:
*               type: string
*             city:
*               type: string
*             street:
*               type: string
*             postalCode:
*               type: string

*         required:
*           - firstName
*           - email
*           - password
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
 
   /notarycam/getUser:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: To get a user detail
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userIds:
*               type: array
*               items:
*                   type: string
*             emails:
*               type: array
*               items:
*                   type: string

*         required:
*           - userIds
*           - emails

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
   /notarycam/getUserDetails:
 *   get:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To get a user details .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
  
    /notarycam/transactions:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: user transaction
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             department:
*               type: string
*             participants:
*               type: array
*               items:
*                   type: object
*                   properties:
*                      user:
*                        type: string
*                      role:
*                        type: string
*           
*         required:
*           - user
*           - role

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
  /notarycam/getTransactions:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: To get a transactions detail
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userIds:
*               type: array
*               items:
*                   type: string
*             emails:
*               type: array
*               items:
*                   type: string
*             departmentIds:
*               type: array
*               items:
*                   type: string

*         required:
*           - userIds
*           - emails
*           - departmentIds

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
    /notarycam/getTransactionDetails:
 *   get:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To get a particular transaction details .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: transactionId  
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
     /notarycam/activateTransactionDetails:
 *   put:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To activate a transaction .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: body
 *         in: body
 *         schema: 
 *           type: object
 *           properties:
 *             transactionId:
 *               type: string
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
    /notarycam/archiveTransactionDetails:
 *   put:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To archive a transaction .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: body
 *         in: body
 *         schema: 
 *           type: object
 *           properties:
 *             transactionId:
 *               type: string
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /notarycam/addParticipantsToTransaction:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: Add a participants to transaction
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             transactionId:
*               type: string
*             participants:
*               type: array
*               items:
*                   type: object
*                   properties:
*                      user:
*                        type: string
*                      role:
*                        type: string
*                      redirectURL:
*                        type: string

*           
*         required:
*           - user
*           - role
*           - redirectURL

*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
* 
  /notarycam/removeParticipantsFromTransactions:
 *   put:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To remove a  participants from transaction .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: body
 *         in: body
 *         schema: 
 *           type: object
 *           properties:
 *             transactionId:
 *               type: string
 *             userId:
 *               type: string
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /notarycam/saveDocuments:
*   post:
*     tags:
*       - notarycam
*     name: user
*     summary: Add a documents for a transaction
*     security:
*       - bearerAuth: []
*     consumes:
*       -  multipart/form-data
*     produces:
*       - application/json
*     parameters: 
*       - in: formData
*         name: documents
*         type: file
*         required: true 
*       - in: formData
*         name: type
*         type: string
*         required: true 
*       - in: formData
*         name: transactionId
*         type: string
*         required: true 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 
*
   /notarycam/getDocumentDetails:
 *   get:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To get a document details .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: transactionId
 *         type: string
 *         required: true
 *       - in: query
 *         name: documentId
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /notarycam/downloadDocuments:
 *   get:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To download a document  .
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: transactionId
 *         type: string
 *         required: true
 *       - in: query
 *         name: documentId
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
    /notarycam/removeDocuments:
 *   put:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: To remove  a document.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - name: body
 *         in: body
 *         schema: 
 *           type: object
 *           properties:
 *             transactionId:
 *               type: string
 *             documentId:
 *               type: string
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *
   /notaryCam/getParticipantsDetails:
 *   get:
 *     tags:
 *       - notarycam
 *     name: notarycam
 *     summary: Get list of all participants details
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: name

 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error. 
*/

var express = require('express');
const router = express.Router();
var objCase = require('../dao/notaryCam');
var jwtAuth = require('../dao/jwt');
var multiparty = require ('connect-multiparty')
multipartyMiddleware =  multiparty();
router.use(multipartyMiddleware);
//var fs = require('fs'); 

router.post('/signUp', async function (req, res, next) {
    try {
        var result = await objCase.saveUser(req, res, next);
        console.log(result);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});

router.post('/getUser', async function (req, res, next) {
    try {
        if (req.body.userIds == '' || req.body.userIds == undefined) {
            return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
        }

        var result = await objCase.getUser(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/getUserDetails', async function (req, res, next) {
    try {

        var result = await objCase.getUserDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.post('/transactions', async function (req, res, next) {
    try {
        var result = await objCase.transactions(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});

router.post('/getTransactions', async function (req, res, next) {
    try {
        if (req.body.userIds == '' || req.body.userIds == undefined) {
            return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
        }

        var result = await objCase.getTransactions(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/getTransactionDetails', async function (req, res, next) {
    try {

        var result = await objCase.getTransactionDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.put('/activateTransactionDetails', async function (req, res, next) {
    try {

        var result = await objCase.activateTransactionDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.put('/removeParticipantsFromTransactions', async function (req, res, next) {
    try {

        var result = await objCase.removeParticipantsFromTransactions(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.put('/archiveTransactionDetails', async function (req, res, next) {
    try {

        var result = await objCase.archiveTransactionDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.post('/addParticipantsToTransaction', async function (req, res, next) {
    try {
        var result = await objCase.addParticipantsToTransaction(req, res, next);
        console.log(result);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.post('/saveDocuments', async function (req, res, next) {
    try {
            
        var result = await objCase.saveDocuments(req, res, next);
       
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});


router.get('/getDocumentDetails', async function (req, res, next) {
    try {

        var result = await objCase.getDocumentDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/downloadDocuments', async function (req, res, next) {
    try {

        var result = await objCase.downloadDocuments(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.put('/removeDocuments', async function (req, res, next) {
    try {

        var result = await objCase.removeDocuments(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }


    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/getParticipantsDetails', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (
            req.query.count == '' ||
            req.query.count == undefined ||
            req.query.count == 0
        ) {
            req.query.count = 10;
        }
        if (
            req.query.offset == '' ||
            req.query.offset == undefined ||
            req.query.offset == 0
        ) {
            req.query.offset = 0;
        }
        var result = await objCase.getParticipantsDetails(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});



module.exports = router;
