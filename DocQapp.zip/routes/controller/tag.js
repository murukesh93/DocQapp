
/**
* @swagger 
*  /tag/saveTag:
*   post:
*     tags:
*       - tag
*     name: tag
*     summary: To create a new tag
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             tagName:
*               type: string
*             userId:
*               type: integer
*             color:
*               type: string
*         required:
*           - userId
*           - tagName
*
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 

 * /tag/listTag:
 *   get:
 *     tags:
 *       - tag
 *     name: tag
 *     summary: Get list of all user tags
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: offset
 *         type: integer
 *       - in: query
 *         name: count
 *         type: integer
 *       - in: query
 *         name: tagName
 *         type: string
 *       - in: query
 *         name: tagId
 *         type: string
 *       - in: query
 *         name: userId
 *         type: integer

 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.


*/

var express = require('express');
const router = express.Router();
var objTagDAO = require('../dao/tag');
var jwtAuth = require('../dao/jwt'); 

router.post('/saveTag', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (req.body.tagName == '' || req.body.tagName == undefined) {
            return res.status(403).json({ status: 'Error', message: 'tagName is required!' });
        }
         
        if (req.body.userId == '' || req.body.userId == undefined ||  req.body.userId<=0 ) {
            return res.status(403).json({ status: 'Error', message: 'userId is required!' });
        }  
        

        req.body.tagId = 0;
        req.body.action = 'Add';

        var result = await objTagDAO.saveTag(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }

});

router.get('/listTag', jwtAuth.VerifyToken, async function (req, res, next) {
    try {
        if (
            req.query.count == '' ||
            req.query.count == undefined ||
            req.query.count == 0
        ) {
            req.query.count = 10;
        }
        if (
            req.query.offset == '' ||
            req.query.offset == undefined ||
            req.query.offset == 0
        ) {
            req.query.offset = 0;
        }
        var result = await objTagDAO.listTag(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});



          

module.exports = router;