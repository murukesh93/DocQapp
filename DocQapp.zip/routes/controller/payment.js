 
/**
* @swagger 
*  /payment/subscribePlans:
*   post:
*     tags:
*       - payment
*     name: payment
*     summary: To create a new tag
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             amount:
*               type: integer
*             paymentResponse:
*               type: string
*             paymentPurpose:
*               type: string
*             bankTransactionId:
*               type: integer
*             paymentStatus:
*               type: string
*             customerId:
*               type: integer
*             subscriptionPlanId:
*               type: integer
*             planDuration:
*               type: integer
*
*     responses:
*        200:
*          description: Record saved successfully...
*        401:
*         description: Unauthorized.
*        500:
*         description: Internal Server Error.
*
* /payment/getSubscriptionPlanByUserId:
 *   get:
 *     tags:
 *       - payment
 *     name: payment
 *     summary: To select particular user details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: userId
 *         type: integer
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *


* /payment/getPlan:
 *   get:
 *     tags:
 *       - payment
 *     name: payment
 *     summary: To select plan details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 * 
 *     responses:
 *       200:
 *        description: Return user object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *

* 
*/

var express = require('express');
const router = express.Router();
var objPaymentDAO = require('../dao/payment');
var jwtAuth = require('../dao/jwt');

router.post('/subscribePlans', jwtAuth.VerifyToken,async function (req, res, next) {
    try { 
        var result = await objPaymentDAO.subscribePlans(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/getSubscriptionPlanByUserId', jwtAuth.VerifyToken,async function (req, res, next) {
    try {
        if (req.query.userId == '' || req.query.userId == undefined) {
            return res.status(403).json({ status: 'Error', message: 'UserId is required!' });
        }
      
        var result = await objPaymentDAO.getUserSubscription(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

router.get('/getPlan',async function (req, res, next) {
    try { 
      
        var result = await objPaymentDAO.getPlan(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }

    } catch (ex) {
        var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
    }
});

          

module.exports = router;