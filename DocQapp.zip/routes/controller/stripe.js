/**
* @swagger 
 

* /stripe/createCustomer:
*   post:
*     tags:
*       - stripe
*     name: stripe
*     summary: Create new customer
*     security:
*       - bearerAuth: []
*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             userId:
*               type: integer
*             name:
*               type: string
*             phone:
*               type: string
*             email:
*               type: string
*         required:
*           - name
*           - phone
*           - email

*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /stripe/createCard:
*   post:
*     tags:
*       - stripe
*     name: stripe
*     summary: Create new card
*     security:
*       - bearerAuth: []

*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             customerId:
*               type: string
*             cardToken:
*               type: string
 
*         required:
*           - customerId
*           - cardToken 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


 * /stripe/listCard:
 *   get:
 *     tags:
 *       - stripe
 *     name: stripe
 *     summary: To select particular customer card details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: customerId
 *         type: string
 *         required: true
 * 
 *     responses:
 *       200:
 *        description: Return customer card object
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *

 * /stripe/deleteCard:
 *   delete:
 *     tags:
 *       - stripe
 *     name: stripe
 *     summary: Delete a customer card details.
 *     security:
 *       - bearerAuth: []
 *     consumes:
 *       - application/json
 *     produces:
 *       - application/json
 *     parameters:
 *       - in: query
 *         name: customerId
 *         type: string
 *         required: true
 *       - in: query
 *         name: cardId
 *         type: string
 *         required: true
 *     responses:
 *       200:
 *        description: Record deleted successfully
 *       400:
 *        description: Invalid Token key.
 *       401:
 *        description: Unauthorized.
 *       500:
 *        description: Internal Server Error.
 *

 * /stripe/createPayment:
*   post:
*     tags:
*       - stripe
*     name: stripe
*     summary: Create new stripe payment 
*     security:
*       - bearerAuth: []

*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             customerId:
*               type: string
*             amount:             
*               type: number
*               format: float
*             description:
*               type: string
 
*         required:
*           - customerId
*           - amount 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


* /stripe/setDefaultCard:
*   post:
*     tags:
*       - stripe
*     name: stripe
*     summary: Set default card for transaction
*     security:
*       - bearerAuth: []

*     consumes:
*       - application/json
*     parameters:
*       - name: body
*         in: body
*         schema: 
*           type: object
*           properties:
*             customerId:
*               type: string
*             cardId:
*               type: string
 
*         required:
*           - customerId
*           - cardId 
*     responses:
*       200:
*         description: Record saved successfully...
*       401:
*        description: Unauthorized.
*       500:
*        description: Internal Server Error. 


*/



var express = require('express');
const router = express.Router();
var objStripe=require('../dao/stripe')
var jwtAuth=require('../dao/jwt');

router.post('/createCustomer', jwtAuth.VerifyToken,async function(req, res,next) {
    try {
     
      if(req.body.email=='' ||req.body.email==undefined ){
        return res.status(403).json({status:'Error',message:'email is required!'});
      }
      if(req.body.name=='' ||req.body.name==undefined ){
        return res.status(403).json({status:'Error',message:'name is required!'});
      }
      
      if(req.body.phone=='' ||req.body.phone==undefined ){
        return res.status(403).json({status:'Error',message:'phone is required!'});
      }

    var result = await objStripe.createCustomer(req, res, next);
    if (result.status === 'Error') {
        return res.status(500).json(result);
    } else {
        return res.status(200).json(result);
    }


    } catch (ex) {
     var result = { status: 'Error', message: ex.message };
      return res.status(500).json(result);
    }
  });
  

router.post('/createCard', jwtAuth.VerifyToken,async function(req, res,next) {
    try {
      
      if(req.body.cardToken=='' ||req.body.cardToken==undefined ){
        return res.status(403).json({status:'Error',message:'cardToken is required!'});
      }
      if(req.body.customerId=='' ||req.body.customerId==undefined ){
        return res.status(403).json({status:'Error',message:'customerId is required!'});
      }

      var result = await objStripe.addCard(req, res, next);
      if (result.status === 'Error') {
          return res.status(500).json(result);
      } else {
          return res.status(200).json(result);
      }

    } catch (ex) {
     var result = { status: 'Error', message: ex.message };
      return res.status(500).json(result);
    }
  });
  
router.delete('/deleteCard', jwtAuth.VerifyToken,async function(req, res,next) {
  try {
   
    if(req.query.customerId=='' ||req.query.customerId==undefined ){
      return res.status(403).json({status:'Error',message:'customerId is required!'}); 
    } 
    if(req.query.cardId=='' ||req.query.cardId==undefined ){
      return res.status(403).json({status:'Error',message:'cardId is required!'}); 
    } 
    
    var result = await objStripe.deleteCard(req, res, next);
      if (result.status === 'Error') {
          return res.status(500).json(result);
      } else {
          return res.status(200).json(result);
      }


  } catch (ex) {
     var result = { status: 'Error', message: ex.message };
    return res.status(500).json(result);
  } 
  });

  router.get('/listCard',jwtAuth.VerifyToken,async function(req, res,next) {
    try {
     
      if(req.query.customerId=='' || req.query.customerId==undefined ){
        return res.status(403).json({status:'Error',message:'customerId is required!'});
     
      } 
      var result = await objStripe.listCard(req, res, next);
      if (result.status === 'Error') {
          return res.status(500).json(result);
      } else {
          return res.status(200).json(result);
      }


    } catch (ex) {
       var result = { status: 'Error', message: ex.message };
      return res.status(500).json(result);
    } 
    });

router.post('/createPayment', jwtAuth.VerifyToken,async function(req, res,next) {
      try {
        
        if(req.body.amount=='' ||req.body.amount==undefined ){
          return res.status(403).json({status:'Error',message:'amount is required!'});
        }
        if(req.body.customerId=='' ||req.body.customerId==undefined ){
          return res.status(403).json({status:'Error',message:'customerId is required!'});
        }
        // if(req.body.source=='' ||req.body.source==undefined ){
        //   return res.status(403).json({status:'Error',message:'source is required!'});
        // }
        var result = await objStripe.createPayment(req, res, next);
        if (result.status === 'Error') {
            return res.status(500).json(result);
        } else {
            return res.status(200).json(result);
        }
  
        
      } catch (ex) {
       var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
      }
    });


router.post('/setDefaultCard', jwtAuth.VerifyToken,async function(req, res,next) {
      try {
        
        if(req.body.cardId=='' ||req.body.cardId==undefined ){
          return res.status(403).json({status:'Error',message:'cardId is required!'});
        }
        if(req.body.customerId=='' ||req.body.customerId==undefined ){
          return res.status(403).json({status:'Error',message:'customerId is required!'});
        }
  
        var result = await objStripe.setDefaultCard(req, res, next);
      if (result.status === 'Error') {
          return res.status(500).json(result);
      } else {
          return res.status(200).json(result);
      }


      } catch (ex) {
       var result = { status: 'Error', message: ex.message };
        return res.status(500).json(result);
      }
    });
    

    module.exports = router;