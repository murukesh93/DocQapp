
var ConnectionString = {
    server: '',
    database: '',
    user: '',
    password: '',
}

 
module.exports.ConnectionString = ConnectionString; 
 