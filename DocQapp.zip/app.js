var express = require('express');
var http = require('http');
var path = require('path');
var cors = require('cors');
var  bodyparser = require('body-parser');
var swaggerUi = require('swagger-ui-express');
var swaggerJSDoc = require('swagger-jsdoc');
var methodOverride = require('method-override');
var busboy = require('connect-busboy');
 var app = express();


const swaggerDefinition = {
  info: {
    title: 'DocqApp API',
    version: '1.0.0',
    description: 'Endpoints to test the user registration routes'
  }, 
 host: 'localhost:3001',
 //host:'devdocqapp.azurewebsites.net',
   basePath: '/', 
   securityDefinitions: {  
    bearerAuth: {
      type: 'apiKey',  
      name: 'authorization',
      scheme: 'bearer',
      in: 'header',
    },
  }
};
  
const options = {
  swaggerDefinition,
  apis: ['./routes/controller/*.js']
};
var test = require('./routes/controller/test');
var user=require('./routes/controller/user');
var uploadFile=require('./routes/controller/uploadFile');
var tag=require('./routes/controller/tag');
var efile=require('./routes/controller/efile');
var stripe=require('./routes/controller/stripe');
var payment=require('./routes/controller/payment');
var common=require('./routes/controller/common');
var caseDetails=require('./routes/controller/caseDetails');
var notarycam=require('./routes/controller/notarycam');
app.use(cors());
app.use(bodyparser.urlencoded({ extended: true }));
app.use(bodyparser.json());
app.use(methodOverride());
app.use(busboy());
app.use(express.static(path.join(__dirname, 'public')));


app.use('/test', test);
app.use('/user', user);
app.use('/uploadFile',uploadFile);
app.use('/tag',tag);
app.use('/efile',efile);
app.use('/stripe',stripe);
app.use('/payment',payment);
app.use('/common',common);
app.use('/case',caseDetails);
app.use('/notarycam',notarycam);
const swaggerSpec = swaggerJSDoc(options);
app.get('/swagger.json', function(req, res) {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});


app.use('/', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

//if we are here then the specified request is not found
app.use((req, res, next) => {
  const err = new Error('Not Found');
  err.status = 404;
  next(err);
});

//all other requests are not implemented.
app.use((err, req, res) => {
  res.status(err.status || 501);
  res.json({
    error: {
      code: err.status || 501,
      message: err.message
    }
  });
});

module.exports = app;

//Use system configuration for port or use 6001 by default.
const port = process.env.PORT || 3001;

//Create server with exported express app
const server = http.createServer(app);

server.listen(port, () => console.log(`app is running at ${port}`));